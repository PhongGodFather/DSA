#include <iostream>
using namespace std;
void merge(int arr[], int aux[], int low, int mid, int high)
{
    int k = low, i = low, j = mid + 1;
    while (i <= mid && j <= high)
    {
        if (arr[i] <= arr[j])
            aux[k++] = arr[i++];
        else
            aux[k++] = arr[j++];
    }
    while (i <= mid)
        aux[k++] = arr[i++];
    for (int i = low; i <= high; i++)
        arr[i] = aux[i];
}
template <class Item>
void mergesort_1(Item a[], Item aux[], int l, int r)
{
    if (r <= l)
        return;
    int m = l + (r - l) / 2; // avoid out of bound
    bool flag = 0;
    for (int i = l + 1; i <= m; ++i)
        if (a[i - 1] > a[i])
            flag = 1;
    if (flag)
        mergesort_1(a, aux, l, m);
    flag = 0;
    for (int i = m + 1; i <= r; ++i)
        if (a[i - 1] > a[i])
            flag = 1;
    if (flag)
        mergesort_1(a, aux, m + 1, r);
    merge(a, aux, l, m, r);
}
template <class Item>
void mergesort_2(Item a[], Item aux[], int l, int r)
{
    if (r <= l)
        return;
    int m = (l + r) / 2;
    mergesort_2(a, aux, l, m);
    mergesort_2(a, aux, m + 1, r);
    merge(a, aux, l, m, r);
}
template <class Item>
void mergesort_3(Item a[], Item aux[], int l, int r) // the merge sorting method without using the recursive method
{
    for (int sz = 1; sz <= r - l; sz = sz + sz)
        for (int i = l; i <= r - sz; i += sz + sz)
            merge(a, aux, i, i + sz - 1, min(i + sz + sz - 1, r));
}
int main()
{
    int a[] = {4, 5, 1, 2, 3, 8, 7, 9};
    int aux[] = {4, 5, 1, 2, 3, 8, 7, 9}; // auxilary array just the same as the previous one
    mergesort_3(a, aux, 0, sizeof(a) / sizeof(a[0]));
    for (int i = 0; i < sizeof(a) / sizeof(a[0]); i++)
        cout << a[i] << " ";
}