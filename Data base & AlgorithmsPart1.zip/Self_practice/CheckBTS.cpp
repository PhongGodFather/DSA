#include <iostream>
#include <set>
using namespace std;
struct Node
{
    int data;
    Node *left, *right;
    Node(int key)
    {
        data = key;
        left = right = nullptr;
    }
};
void NhapMang(Node *root, set<int> &s)
{
    if (!root)
        return;
    NhapMang(root->left, s);
    s.insert(root->data);
    NhapMang(root->right, s);
}
int search(Node *tree, int x)
{
    if (tree == nullptr)
        return -1;
    if (tree->data == x)
        return tree->data;
    if (tree->data > x)
        return search(tree->left, x);
    else
    {
        int temp = search(tree->right, x);
        if (temp <= x)
            return temp;
        else
            return tree->data;
    }
}
bool subset(Node *tree1, Node *tree2)
{
    set<int> a;
    NhapMang(tree1, a);
    for (auto i = a.begin(); i != a.end(); i++)
    {
        int k = search(tree2, *i);
        if (k == -1)
            return false;
    }
    return true;
}
void insert(Node *&tree, int key)
{
    if (tree == nullptr)
        tree = new Node(key);
    else
    {
        if (tree->data == key)
            return;
        if (key < tree->data)
            insert(tree->left, key);
        if (key > tree->data)
            insert(tree->right, key);
    }
}
int main()
{
    Node *T2 = nullptr;
    insert(T2, 15);
    insert(T2, 10);
    insert(T2, 20);
    insert(T2, 5);
    insert(T2, 12);
    insert(T2, 25);
    insert(T2, 30);

    Node *T1 = nullptr;
    insert(T1, 30);
    insert(T1, 15);
    cout << subset(T1, T2);
}