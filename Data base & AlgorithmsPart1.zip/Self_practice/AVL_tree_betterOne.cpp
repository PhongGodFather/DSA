#include <iostream>
using namespace std;
struct Node
{
    int data;
    int height;
    Node *left, *right;
    Node(int key)
    {
        height = 1;
        data = key;
        left = right = nullptr;
    }
};
class AVL
{
public:
    Node *root;
    AVL() { root = nullptr; }
    void printTree(Node *tree, int h);
    void printTree() { printTree(root, 0); }
    void printTree_v2(Node *tree, int h);
    void printTree_v2() { printTree_v2(root, 0); }
    int height(Node *r);
    void leftRotate(Node *&avl);
    void rightRotate(Node *&avl);
    int getBalance(Node *avl);
    void insert(Node *&avl, int key);
    void insert(int key) { insert(root, key); }
    Node *minValueNode(Node *node);
    void deleteNode(Node *tree, int key);
    void deleteNode(int key) { deleteNode(root, key); }
};
void AVL::printTree(Node *tree, int h)
{
    Node *r = tree;
    if (r == nullptr)
    {
        for (int i = 0; i < h; i++)
            cout << "   ";
        cout << "*" << endl;
    }
    else
    {
        printTree(r->right, h + 1);
        for (int i = 0; i < h; i++)
            cout << "   ";
        cout << r->data << endl;
        printTree(r->left, h + 1);
    }
}
void AVL::printTree_v2(Node *tree, int h)
{
    Node *r = tree;
    if (r == nullptr)
        return;
    else
    {
        if (r->right)
            printTree_v2(r->right, h + 3);
        for (int i = 0; i < h; i++)
            cout << " ";
        cout << " ";
        if (r->right)
        {
            cout << " /\n";
            for (int i = 0; i < h; i++)
                cout << " ";
            cout << " ";
        }
        cout << r->data << "\n ";
        if (r->left)
        {
            for (int i = 0; i < h; i++)
                cout << " ";
            cout << "  \\\n";
            printTree_v2(r->left, h + 3);
        }
    }
}
int AVL::height(Node *r)
{
    if (r == nullptr)
        return 0;
    return r->height;
}
void AVL::leftRotate(Node *&avl)
{
    Node *x = avl->right;
    avl->right = x->left;
    x->left = avl;
    avl->height = max(height(avl->left), height(avl->right)) + 1;
    x->height = max(height(x->left), avl->height) + 1;
    avl = x;
}
void AVL::rightRotate(Node *&avl)
{
    Node *x = avl->left;
    avl->left = x->right;
    x->right = avl;
    avl->height = max(height(avl->left), height(avl->right)) + 1;
    x->height = max(height(x->left), avl->height) + 1;
    avl = x;
}
int AVL::getBalance(Node *avl)
{
    if (avl == nullptr)
        return 0;
    return height(avl->left) - height(avl->right);
}
void AVL::insert(Node *&avl, int key)
{
    if (avl == nullptr)
        avl = new Node(key);
    else
    {
        if (avl->data == key)
            return;
        if (avl->data < key)
            insert(avl->right, key);
        if (avl->data > key)
            insert(avl->left, key);
        avl->height = 1 + max(height(avl->left), height(avl->right));
        int balance = getBalance(avl);
        if (balance > 1 && key < avl->left->data)
        {
            rightRotate(avl);
            return;
        }
        if (balance < -1 && key > avl->right->data)
        {
            leftRotate(avl);
            return;
        }
        if (balance > 1 && key > avl->left->data)
        {
            leftRotate(avl->left);
            rightRotate(avl);
            return;
        }
        if (balance < -1 && key < avl->right->data)
        {
            rightRotate(avl->right);
            leftRotate(avl);
            return;
        }
    }
}
Node *AVL::minValueNode(Node *node)
{
    Node *current = node;
    while (current->left != NULL)
        current = current->left;
    return current;
}
void AVL::deleteNode(Node *root, int key)
{
    if (root == NULL)
        return;
    if (key < root->data)
        deleteNode(root->left, key);
    else if (key > root->data)
        deleteNode(root->right, key);
    else
    {
        if ((root->left == NULL) || (root->right == NULL))
        {
            Node *temp = root->left ? root->left : root->right;
            if (temp == NULL)
            {
                temp = root;
                root = NULL;
            }
            else
                *root = *temp;
            delete temp;
        }
        else
        {
            Node *temp = minValueNode(root->right);
            root->data = temp->data;
            deleteNode(root->right, temp->data);
        }
    }
    // rebalance after deleting
    if (root == NULL)
        return;
    root->height = 1 + max(height(root->left), height(root->right));
    int balance = getBalance(root);
    if (balance > 1 && getBalance(root->left) >= 0)
    {
        rightRotate(root);
        return;
    }
    if (balance > 1 && getBalance(root->left) < 0)
    {
        leftRotate(root->left);
        rightRotate(root);
        return;
    }
    if (balance < -1 && getBalance(root->right) <= 0)
    {
        leftRotate(root);
        return;
    }
    if (balance < -1 && getBalance(root->right) > 0)
    {
        rightRotate(root->right);
        leftRotate(root);
        return;
    }
}
int main()
{
    AVL tree;
    tree.insert(4);
    tree.insert(3);
    tree.insert(5);
    tree.insert(1);
    tree.insert(2);
    tree.insert(7);
    tree.insert(9);
    tree.insert(8);
    tree.insert(15);
    tree.insert(11);
    tree.insert(12);
    tree.insert(16);
    //  tree.printTree();
    tree.deleteNode(15);
    tree.deleteNode(4);
    tree.printTree_v2();
}