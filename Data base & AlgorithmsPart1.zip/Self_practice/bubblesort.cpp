#include <iostream>
using namespace std;
template <class Item>
void bubbleSort(Item a[], int l, int r) 
{
    if (l == r)
        return;
    bool sorted = true;
    for (int i = l + 1; i < r; i++)
        if (a[i] < a[l])
        {
            swap(a[i], a[l]);
            sorted = false;
        }
    if (sorted == false)
        bubbleSort(a, l + 1, r);
}

int main()
{
    int a[] = {4, 5, 1, 2, 3, 8, 7, 9};
    bubbleSort(a, 0, sizeof(a) / sizeof(a[0]));
    for (int i = 0; i < sizeof(a) / sizeof(a[0]); i++)
        cout << a[i] << " ";
}