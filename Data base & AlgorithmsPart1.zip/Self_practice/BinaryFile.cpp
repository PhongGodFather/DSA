#include <iostream>
#include <fstream>
#include <string>
using namespace std;
struct SV
{
    char name[50];
    int mathScore, physicsScore, chemistryScore;
};
struct Node
{
    SV data;
    Node *next;
    Node(SV key)
    {
        data = key;
        next = nullptr;
    }
};
void append(Node *&list, SV key)
{
    if (list == nullptr)
        list = new Node(key);
    else
        append(list->next, key);
}
void show(Node *list)
{
    for (auto i = list; i; i = i->next)
        printf("%-10s | %-10d | % -10d | %d\n", i->data.name, i->data.mathScore, i->data.physicsScore, i->data.chemistryScore);
}
void readAndInsert(Node *&head)
{
    fstream rf("ListStudent.txt", ios::in | ios::binary);
    int n;
    rf.read((char*)&n, sizeof(n));
    int i = 0;
    while (i < n)
    {
        SV temp;
        rf.read((char *)&temp, sizeof(SV));
        append(head, temp);
        i++;
    }
    rf.close();
}
void test_write(Node *list)
{
    fstream wf("ListStudent.txt", ios::out | ios::binary);
    int size = 9;
    wf.write((char*)&size, sizeof(size));
    for (auto i = list; i; i = i->next)
        wf.write((char *)&i->data, sizeof(SV));
    wf.close();
}
int main()
{
    Node *list = nullptr;
    // SV sv[9] = {{"Thuy Linh", 9, 8, 7}, {"Thomas", 7, 9, 6}, {"Xuan Hoang", 5, 6, 5}, {"Henry", 10, 7, 8}, {"Ngoc", 6, 7, 9}, {"Huy Quang", 8, 9, 7}, {"Quang Dat", 5, 4, 6}, {"Hoang Phan", 7, 8, 9}, {"Ngoc Anh", 9, 9, 9}};
    // for (int i = 0; i < 9; i++)
    //     append(list, sv[i]);
    // test_write(list);
    readAndInsert(list);
    show(list);
}