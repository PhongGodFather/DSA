#include <iostream>
#include <map>
#include <fstream>
#include <string>
using namespace std;
struct Node
{
	string name;
	Node *left, *right;
	Node(string item)
	{
		name = item;
		left = right = NULL;
	}
	void adoptChild(Node *child1, Node *child2)
	{
		left = child1;
		right = child2;
	}
};
void Preorder(Node *tree)
{
	if (tree == NULL)
		return;
	cout << tree->name << " ";
	Preorder(tree->left);
	Preorder(tree->right);
}
void Inorder(Node *tree)
{
	if (tree == NULL)
		return;
	Inorder(tree->left);
	cout << tree->name << " ";
	Inorder(tree->right);
}
void Postorder(Node *tree)
{
	if (tree == NULL)
		return;
	Postorder(tree->left);
	Postorder(tree->right);
	cout << tree->name << " ";
}
void printTree(Node *tree, int h)
{
	Node *r = tree;
	if (r == nullptr)
		return;
	else
	{
		if (r->right)
			printTree(r->right, h + 3);
		for (int i = 0; i < h; i++)
			cout << " ";
		cout << " ";
		if (r->right)
		{
			cout << " /\n";
			for (int i = 0; i < h; i++)
				cout << " ";
			cout << " ";
		}
		cout << r->name << "\n ";
		if (r->left)
		{
			for (int i = 0; i < h; i++)
				cout << " ";
			cout << "  \\\n";
			printTree(r->left, h + 3);
		}
	}
}
int search(Node *a[], string x, int n)
{
	for (int i = 0; i < n; i++)
		if (a[i]->name == x)
			return i;
	return -1;
}
void construct(Node *a[])
{
	int n, i = 0;
	fstream file("input.txt", ios::in);
	file >> n;
	while (!file.eof())
	{
		char ch;
		string temp, temp1, temp2, space;
		file >> ch;
		getline(file, temp, ' ');
		Node *k = nullptr;
		if (search(a, temp, i) == -1)
		{
			k = new Node(temp);
			a[i] = k;
			i++;
		}
		else
			k = a[search(a, temp, i)];
		file >> ch;
		getline(file, temp1, ' ');
		Node *k1 = nullptr;
		if (search(a, temp1, i) == -1)
		{
			k1 = new Node(temp1);
			a[i] = k1;
			i++;
		}
		else
			k1 = a[search(a, temp1, i)];
		getline(file, temp2, ')');
		Node *k2 = nullptr;
		getline(file, space, '\n'); // passby the rest of the line
		if (search(a, temp2, i) == -1)
		{
			k2 = new Node(temp2);
			a[i] = k2;
			i++;
		}
		else
			k2 = a[search(a, temp2, i)];
		k->adoptChild(k1, k2);
	}
	file.close();
}
int main()
{
	Node *a[100];
	construct(a);
	Node *tree = a[0];
	printTree(tree, 0);
	//  Preorder(tree);
	//  Inorder(tree);
	//  Postorder(tree);
}