#include <iostream>
using namespace std;
struct Node
{
    int data;
    Node *next;
    Node(int key)
    {
        data = key;
        next = nullptr;
    }
};
void append(Node *&list, int key)
{
    if (list == nullptr)
        list = new Node(key);
    else
        append(list->next, key);
}
void show(Node *list)
{
    for (auto i = list; i; i = i->next)
        cout << i->data << " ";
}
void deleteDuplicate(Node *&list)
{
    Node *ptr1 = list;
    while (ptr1 != NULL && ptr1->next != NULL)
    {
        Node *ptr2 = ptr1;
        while (ptr2->next != NULL)
        {
            if (ptr1->data == ptr2->next->data)
            {
                Node *dup = ptr2->next;
                ptr2->next = ptr2->next->next;
                delete dup;
            }
            else
                ptr2 = ptr2->next;
        }
        ptr1 = ptr1->next;
    }
}
int main()
{
    Node *list = nullptr;
    append(list, 1);
    append(list, 10);
    append(list, 1);
    append(list, 2);
    append(list, 10);
    show(list);
    cout << endl;
    deleteDuplicate(list);
    show(list);
}