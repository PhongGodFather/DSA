#include <iostream>
#include <vector>
using namespace std;
vector<string> String_out(int a[], int n)
{
    vector<string> temp;
    int max = 0, k = 0;
    for (int i = 1; i < n; i++)
        if (max < n / i)
            max = i;
    max++;
    int i = 0;
    while (true)
    {
        string t = "";
        for (int j = 0; j < max; j++, k++)
            t += a[k] + '0';
        temp.push_back(t);
        max--;
        cout << max << " ";
        if (max == 0)
            max++;
        if (i == n - 1)
            break;
        i++;
    }
    return temp;
}
int main()
{
    int a[] = {0, 1, 2, 4, 5, 7, 9};
    int n = sizeof(a) / sizeof(a[0]);
    vector<string> temp = String_out(a, n);
    for (auto i = temp.begin(); i != temp.end(); i++)
        cout << *i << " ";
}