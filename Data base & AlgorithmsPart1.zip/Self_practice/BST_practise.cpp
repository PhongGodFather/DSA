#include <iostream>
using namespace std;
struct Node
{
    int data;
    Node *left, *right;
    // constructor for a new node
    Node(int key)
    {
        data = key;
        left = right = NULL;
    }
};
void insert(Node *&tree, int key)
{
    if (tree == nullptr)
        tree = new Node(key);
    else
    {
        if (tree->data == key)
            return;
        if (key < tree->data)
            insert(tree->left, key);
        if (key > tree->data)
            insert(tree->right, key);
    }
}
void printTree(Node *tree, int h) // trees will be printed but from root to the right in landscape view each * is the null branch
{
    // h is the distance between each nodes and branch, recommend h = 0 for closer distance
    Node *r = tree;
    if (r == nullptr)
    {
        for (int i = 0; i < h; i++)
            cout << "   ";
        cout << "*" << endl;
    }
    else
    {
        printTree(r->right, h + 1); // right branch created first
        for (int i = 0; i < h; i++)
            cout << "   ";
        cout << r->data << endl;
        printTree(r->left, h + 1); // proceed left branch below last
    }
}
void printTree_v2(Node *tree, int h)
{
    Node *r = tree;
    if (r == nullptr)
        return;
    else
    {
        if (r->right)
            printTree_v2(r->right, h + 3);
        for (int i = 0; i < h; i++)
            cout << " ";
        cout << " ";
        if (r->right)
        {
            cout << " /\n";
            for (int i = 0; i < h; i++)
                cout << " ";
            cout << " ";
        }
        cout << r->data << "\n ";
        if (r->left)
        {
            for (int i = 0; i < h; i++)
                cout << " ";
            cout << "  \\\n";
            printTree_v2(r->left, h + 3);
        }
    }
}
void rightRotate(Node *&tree) // for version 1 only
{
    Node *swap = tree->left;
    tree->left = tree->right;
    tree->right = tree;
    tree = swap;
}
void rightRotate_v2(Node *&tree) // for printing version 2, not working till now :<
{
    int swap = tree->left->data;
    tree->left->data = tree->right->data;
    tree->right->data = tree->data;
    tree->data = swap;
}
void Preorder(Node *tree)
{
	if (tree == NULL)
		return;
	cout << tree->data << " ";
	Preorder(tree->left);
	Preorder(tree->right);
}
int Max(Node* tree) // The O(logn) fast finding max element
{
    while (tree->right != nullptr)
        tree = tree->right;
    return tree->data;
}
int Min(Node* tree) // This one as well
{
    while (tree->left != nullptr)
        tree = tree->left;
    return tree->data;
}
int main()
{
    Node *BST = nullptr;
    insert(BST, 79);
    insert(BST, 24);
    insert(BST, 4);
    insert(BST, 3);
    insert(BST, 61); // hmm
    insert(BST, 39);
    insert(BST, 56);
    insert(BST, 41);
    insert(BST, 59);
    insert(BST, 71);
    insert(BST, 67);
    insert(BST, 84);
    insert(BST, 94);
    insert(BST, 91);
    //printTree(BST, 0);
    //rightRotate(BST);
    //printTree(BST, 0);
    printTree_v2(BST, 0);
    cout << endl;
    Preorder(BST);
    cout << endl;
    cout <<"\nThe biggest number is: "<< Max(BST) << endl;
    cout <<"\nThe smallest number is: "<< Min(BST) << endl;
}