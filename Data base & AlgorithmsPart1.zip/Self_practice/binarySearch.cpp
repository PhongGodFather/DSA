#include <iostream>
using namespace std;
int binarySearch(int a[], int l, int r, int x) // the most perfect one that include all the case
{
    if (l > r)
        return -1;
    int mid = l + (r - l) / 2;
    if (a[mid] == x)
        return mid;
    else if (a[mid] < x)
        return binarySearch(a, mid + 1, r, x);
    return binarySearch(a, l, mid - 1, x);
}
int binarySearch_v2(int a[], int n, int x)
{
    int l = 0, r = n - 1;
    while (l < r + 1)
    {
        int mid = l + (r - l) / 2;
        if (a[mid] == x)
            return mid;
        if (a[mid] < x)
            l = mid + 1;
        else
            r = mid - 1;
    }
    return -1;
}
int main()
{
    int a[] = {1, 2, 3, 4, 5, 7, 8, 100};
    int n = sizeof(a) / sizeof(a[0]);
    int x = 100;
    cout << binarySearch(a, 0, n - 1, x) << endl;
    cout << binarySearch_v2(a, n, x);
}