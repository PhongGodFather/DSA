#include <iostream>
using namespace std;
struct Node
{
    int data;
    int height;
    Node *left, *right;
    Node(int key)
    {
        height = 1;
        data = key;
        left = right = nullptr;
    }
};
class AVL
{
public:
    Node *root;
    AVL() { root = nullptr; }
    void printTree(Node *tree, int h);
    void printTree() { printTree(root, 0); }
    void printTree_v2(Node *tree, int h);
    void printTree_v2() { printTree_v2(root, 0); }
    int height(Node *r);
    Node *leftRotate(Node *&avl);
    Node *rightRotate(Node *&avl);
    int getBalance(Node *avl);
    Node *insert(Node *&avl, int key);
    void insertTree(int key) { root = insert(root, key); }
    Node *minValueNode(Node *node);
    Node *deleteNode(Node *tree, int key);
    void deleteTree(int key) { deleteNode(root, key); }
};
void AVL::printTree(Node *tree, int h)
{
    Node *r = tree;
    if (r == nullptr)
    {
        for (int i = 0; i < h; i++)
            cout << "   ";
        cout << "*" << endl;
    }
    else
    {
        printTree(r->right, h + 1);
        for (int i = 0; i < h; i++)
            cout << "   ";
        cout << r->data << endl;
        printTree(r->left, h + 1);
    }
}
void AVL::printTree_v2(Node *tree, int h)
{
    Node *r = tree;
    if (r == nullptr)
        return;
    else
    {
        if (r->right)
            printTree_v2(r->right, h + 3);
        for (int i = 0; i < h; i++)
            cout << " ";
        cout << " ";
        if (r->right)
        {
            cout << " /\n";
            for (int i = 0; i < h; i++)
                cout << " ";
            cout << " ";
        }
        cout << r->data << "\n ";
        if (r->left)
        {
            for (int i = 0; i < h; i++)
                cout << " ";
            cout << "  \\\n";
            printTree_v2(r->left, h + 3);
        }
    }
}
int AVL::height(Node *r)
{
    if (r == nullptr)
        return 0;
    return r->height;
}
Node *AVL::leftRotate(Node *&avl)
{
    Node *x = avl->right;
    avl->right = x->left;
    x->left = avl;
    avl->height = max(height(avl->left), height(avl->right)) + 1;
    x->height = max(height(x->left), avl->height) + 1;
    avl = x;
    return avl;
}
Node *AVL::rightRotate(Node *&avl)
{
    Node *x = avl->left;
    avl->left = x->right;
    x->right = avl;
    avl->height = max(height(avl->left), height(avl->right)) + 1;
    x->height = max(height(x->left), avl->height) + 1;
    avl = x;
    return avl;
}
int AVL::getBalance(Node *avl)
{
    if (avl == nullptr)
        return 0;
    return height(avl->left) - height(avl->right);
}
Node *AVL::insert(Node *&avl, int key)
{
    if (avl == nullptr)
        return new Node(key);
    else
    {
        if (avl->data == key)
            return avl;
        if (avl->data < key)
            avl->right = insert(avl->right, key);
        if (avl->data > key)
            avl->left = insert(avl->left, key);
        avl->height = 1 + max(height(avl->left), height(avl->right));
        int balance = getBalance(avl);
        if (balance > 1 && key < avl->left->data)
            return rightRotate(avl);
        if (balance < -1 && key > avl->right->data)
            return leftRotate(avl);
        if (balance > 1 && key > avl->left->data)
        {
            avl->left = leftRotate(avl->left);
            return rightRotate(avl);
        }
        if (balance < -1 && key < avl->right->data)
        {
            avl->right = rightRotate(avl->right);
            return leftRotate(avl);
        }
        return avl;
    }
}
Node *AVL::minValueNode(Node *node)
{
    Node *current = node;
    while (current->left != NULL)
        current = current->left;
    return current;
}
Node *AVL::deleteNode(Node *root, int key)
{
    if (root == NULL)
        return root;
    if (key < root->data)
        root->left = deleteNode(root->left, key);
    else if (key > root->data)
        root->right = deleteNode(root->right, key);
    else
    {
        if ((root->left == NULL) ||
            (root->right == NULL))
        {
            Node *temp = root->left ? root->left : root->right;
            if (temp == NULL)
            {
                temp = root;
                root = NULL;
            }
            else
                *root = *temp;
            delete temp;
        }
        else
        {
            Node *temp = minValueNode(root->right);
            root->data = temp->data;
            root->right = deleteNode(root->right, temp->data);
        }
    }
    if (root == NULL)
        return root;
    root->height = 1 + max(height(root->left), height(root->right));
    int balance = getBalance(root);
    if (balance > 1 && getBalance(root->left) >= 0)
        return rightRotate(root);
    if (balance > 1 && getBalance(root->left) < 0)
    {
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }
    if (balance < -1 && getBalance(root->right) <= 0)
        return leftRotate(root);
    if (balance < -1 && getBalance(root->right) > 0)
    {
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }
    return root;
}
int main()
{
    AVL tree;
    tree.insertTree(4);
    tree.insertTree(3);
    tree.insertTree(5);
    tree.insertTree(1);
    tree.insertTree(2);
    tree.insertTree(7);
    tree.insertTree(9);
    tree.insertTree(8);
    tree.insertTree(15);
    tree.insertTree(11);
    tree.insertTree(12);
    tree.insertTree(16);
    //  tree.printTree();
    tree.deleteTree(15);
    tree.printTree_v2();
}