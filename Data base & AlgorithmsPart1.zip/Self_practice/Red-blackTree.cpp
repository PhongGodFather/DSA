#include <iostream>
using namespace std;
// Implementation of red black tree
class RBT
{
public:
    struct Node
    {
        int key, color; // 1 is red and 0 is black and is used for null node
        Node *left, *right;
        // constructor for creating a Node on each branch of the tree
        Node(int key)
        {
            this->color = 1;
            this->key = key;
            this->left = nullptr;
            this->right = nullptr;
        }
    };
    typedef Node *link;
    link root;
    // constructor for creating a tree
    RBT() { root = nullptr; }
    // implementation
    void printTree(link r, int h)
    {
        if (r == nullptr)
        {
            for (int i = 0; i < h; i++)
                cout << "   ";
            cout << "*" << endl;
        }
        else
        {
            printTree(r->right, h + 1);
            for (int i = 0; i < h; i++)
                cout << "   ";
            cout << r->key << endl;
            printTree(r->left, h + 1);
        }
    }
    void printTree_v2(Node *tree, int h)
    {
        Node *r = tree;
        if (r == nullptr)
            return;
        else
        {
            if (r->right)
                printTree_v2(r->right, h + 3);
            for (int i = 0; i < h; i++)
                cout << " ";
            cout << " ";
            if (r->right)
            {
                cout << " /\n";
                for (int i = 0; i < h; i++)
                    cout << " ";
                cout << " ";
            }
            cout << r->key << "\n ";
            if (r->left)
            {
                for (int i = 0; i < h; i++)
                    cout << " ";
                cout << "  \\\n";
                printTree_v2(r->left, h + 3);
            }
        }
    }
    // interface
    void printTree()
    {
        printTree(root, 0);
    }
    void printTree_v2()
    {
        printTree_v2(root, 0);
    }
    bool isRed(Node *tree)
    {
        if (tree == nullptr)
            return false;
        return tree->color;
    }
    void flipColor(link &r)
    {
        r->left->color = !r->left->color;
        r->right->color = !r->right->color;
        r->color = !r->color;
    }
    // implementation
    void insert(Node *&r, int key) // a self balance red black tree that use the feature of red or black color
    {
        if (r == nullptr)
        {
            r = new Node(key);
            return;
        }
        if (r->key == key)
            return;
        if (r->key > key)
            insert(r->left, key);
        if (r->key < key)
            insert(r->right, key);
        if (isRed(r->right) && !isRed(r->left))
        {
            leftRotate(r);
            swap(r->color, r->left->color);
        }
        if (isRed(r->left) && isRed(r->left->left))
        {
            rightRotate(r);
            swap(r->color, r->right->color);
        }
        if (isRed(r->left) && isRed(r->right))
            flipColor(r);
    }
    // interface
    void insert(int key)
    {
        insert(root, key);
    }
    // the floor main function
    int floor(link root, int key)
    {
        if (!root)
            return -1;
        if (root->key == key)
            return root->key;
        if (root->key > key)
            return floor(root->left, key);
        else
        {
            int temp = floor(root->right, key);
            if (temp <= key)
                return temp;
            else
                return root->key;
        }
    }
    // interface for user to use
    int floor(int key)
    {
        return floor(root, key);
    }
    void rightRotate(link &h)
    {
        link x = h->left;
        h->left = x->right;
        x->right = h;
        h = x;
    }
    void leftRotate(link &h)
    {
        link x = h->right;
        h->right = x->left;
        x->left = h;
        h = x;
    }
    // interface
    void insertRoot(link &r, int key)
    {
        if (r == nullptr)
            r = new Node(key);
        else
        {
            if (r->key == key)
                return;
            if (r->key > key)
            {
                insertRoot(r->left, key);
                rightRotate(r);
                return;
            };
            if (r->key < key)
            {
                insertRoot(r->right, key);
                leftRotate(r);
                return;
            }
        }
    }
    // interface
    void insertRoot(int key)
    {
        insertRoot(root, key);
    }
};
int main()
{
    RBT tree;
    // insert {4, 3, 5, 1, 2, 7, 9, 8}
    tree.insert(4);
    tree.insert(3);
    tree.insert(5);
    tree.insert(1);
    tree.insert(2);
    tree.insert(7);
    tree.insert(9);
    tree.insert(8);
    tree.insert(4);
    tree.insert(111);
    tree.insert(365);
    tree.printTree_v2();
    // cout << tree.floor(9) << endl;
    // cout << "-------------------\n";
    // tree.rightRotate();
    // tree.printTree();
}
