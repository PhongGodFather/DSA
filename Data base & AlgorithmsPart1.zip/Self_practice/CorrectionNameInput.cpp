#include <iostream>
#include <fstream>
#include <string.h>
using namespace std;
string correctionName(string s)
{
    int i;
	for (i = 0; i < s.length(); i++)
		if (s[i] == ' ' && s[i + 1] == ' ' && i + 1 < s.length())
			break;
    cout << i << endl;
	s = s.erase(i, s.length());
	return s;
}
int main()
{
    fstream file("name.txt", ios::in);
    string k;
    getline(file, k, '\n');
    file.close();
    k = correctionName(k);
    cout << k << "|\n";
    char t = '5';
    int h = t - '0';
    cout << h;
}