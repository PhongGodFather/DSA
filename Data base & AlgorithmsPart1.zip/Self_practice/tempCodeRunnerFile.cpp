addVertex(first);
        addVertex(second);