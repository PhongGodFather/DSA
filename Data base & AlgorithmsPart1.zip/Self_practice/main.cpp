#include <bits/stdc++.h>
using namespace std;
struct StudentData
{
    string fullname;
    string dob;
    string address;
    string studentClass;
    int studentID;
};
void WriteStudentData1()
{
    int n;
    StudentData studentData;
    ofstream output("output1.9.bin", ios::binary | ios::out);
    cout << "Class have: ";
    cin >> n;
    for (int i = 1; i <= n; i++)
    {
        cout << "Student " << i << ":\n";
        cout << "Name: ";
        cin.ignore();
        getline(cin, studentData.fullname, '\n');
        cout << "Birthday: ";
        getline(cin, studentData.dob, '\n');
        cout << "Address: ";
        getline(cin, studentData.address, '\n');
        cout << "Class: ";
        getline(cin, studentData.studentClass, '\n');
        cout << "Student ID: ";
        cin >> studentData.studentID;
        output.write((char *)&studentData, sizeof(studentData));
        output.close();
    }
}
void WriteStudentData2()
{
    int i = 1;
    char tmp;
    StudentData studentData;
    ofstream output("output1.9.bin", ios::binary | ios::out);
    do
    {
        cout << "Student " << i << ":\n";
        cout << "Name: ";
        cin.ignore();
        getline(cin, studentData.fullname, '\n');
        cout << "Birthday: ";
        getline(cin, studentData.dob, '\n');
        cout << "Address: ";
        getline(cin, studentData.address, '\n');
        cout << "Class: ";
        getline(cin, studentData.studentClass, '\n');
        cout << "Student ID: ";
        cin >> studentData.studentID;
        i++;
        output.write((char *)&studentData, sizeof(studentData));
        cout << "Continue?\n";
        cin >> tmp;
    } while (tmp == 'y' || tmp == 'Y');
    output.close();
}
void ReadStudentData()
{
    StudentData studentData;
    ifstream input("output1.9.bin", ios::binary | ios::in);
    while (input.read((char *)&studentData, sizeof(studentData)))
    {
        cout << studentData.fullname << "  " << studentData.dob << "  " << studentData.address << "  " << studentData.studentClass << "  " << studentData.studentID << endl;
    }
    input.close();
}
int main()
{
    char tmp;
    // cout << "Do you know how many students you have?" << endl;
    // cin >> tmp;
    // if (tmp == 'Y' || tmp == 'y')
    // {
    //     WriteStudentData1();
    // }
    // if (tmp == 'n' || tmp == 'N')
    // {
    //     WriteStudentData2();
    // }
    // WriteStudentData2();
    // ReadStudentData();
}