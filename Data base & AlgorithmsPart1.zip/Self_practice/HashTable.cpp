#include <iostream>
#include <bits/stdc++.h>
#include <vector>
using namespace std;
// Hash map insert the item using modulo which means that the item would be given to an array with the index that both modulo with the size of array
class Hash
{
    int BUCKET; // No. of buckets
    // Pointer to an array containing buckets
    vector<int> *table;

public:
    Hash(int V); // Constructor
    // inserts a key into hash table
    void insertItem(int x);
    // deletes a key from hash table
    void deleteItem(int key);
    // hash function to map values to key
    int hashFunction(int x) { return (x % BUCKET); }
    void displayHash();
    void CuckooHashing(int x);
    bool isFull()
    {
        for (int i = 0; i < BUCKET; i++)
            if (table[i].empty())
                return false;
        return true;
    }
};
Hash::Hash(int b)
{
    this->BUCKET = b;
    table = new vector<int>[b];
}
void Hash::insertItem(int key) // this is chaining probing method
{
    int index = hashFunction(key);
    table[index].push_back(key);
    // table[index].push_back(key);
}
void Hash::deleteItem(int key)
{
    // get the hash index of key
    int index = hashFunction(key);
    // find the key in (index)th list
    vector<int>::iterator i;
    for (i = table[index].begin(); i != table[index].end(); i++)
    {
        if (*i == key)
            break;
    }
    // if key is found in hash table, remove it
    if (i != table[index].end())
        table[index].erase(i);
}
// function to display hash table
void Hash::displayHash()
{
    for (int i = 0; i < BUCKET; i++)
    {
        cout << i;
        for (auto x : table[i])
            cout << " --> " << x;
        cout << endl;
    }
}
void Hash::CuckooHashing(int x) // or pigeon hashing where u kick the element ass if collision occurs
{
    int index = hashFunction(x);
    if (table[index].empty())
        table[index].push_back(x);
    else
    {
        *table[index].begin() = x;
    }
}
int main()
{
    Hash nice(12);
    // nice.insertItem(123);
    // nice.insertItem(45); // ta có 45, 45, 21 % 12 == 9
    // nice.insertItem(45);
    // nice.insertItem(86);
    // nice.insertItem(21);
    nice.displayHash();
}