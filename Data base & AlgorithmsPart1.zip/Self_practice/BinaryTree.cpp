#include <iostream>
using namespace std;
struct Node
{
    int data;
    Node *left, *right;
    Node(int key)
    {
        data = key;
        left = right = nullptr;
    }
};
int max(int inorder[], int strt, int end);
/* Recursive function to construct binary of size len from
Inorder traversal inorder[]. Initial values of start and end
should be 0 and len -1. */
Node *buildTree(int inorder[], int start, int end)
{
    if (start > end)
        return NULL;
    /* Find index of the maximum element from Binary Tree */
    int i = max(inorder, start, end);
    /* Pick the maximum value and make it root */
    Node *root = new Node(inorder[i]);
    /* If this is the only element in inorder[start..end],
    then return it */
    if (start == end)
        return root;

    /* Using index in Inorder traversal, construct left and
    right subtress */
    root->left = buildTree(inorder, start, i - 1);
    root->right = buildTree(inorder, i + 1, end);
    return root;
}

/* UTILITY FUNCTIONS */
/* Function to find index of the maximum value in arr[start...end] */
int max(int arr[], int strt, int end)
{
    int i, max = arr[strt], maxind = strt;
    for (i = strt + 1; i <= end; i++)
    {
        if (arr[i] > max)
        {
            max = arr[i];
            maxind = i;
        }
    }
    return maxind;
}
void printTree_v2(Node *tree, int h)
{
    Node *r = tree;
    if (r == nullptr)
        return;
    else
    {
        if (r->right)
            printTree_v2(r->right, h + 3);
        for (int i = 0; i < h; i++)
            cout << " ";
        cout << " ";
        if (r->right)
        {
            cout << " /\n";
            for (int i = 0; i < h; i++)
                cout << " ";
            cout << " ";
        }
        cout << r->data << "\n ";
        if (r->left)
        {
            for (int i = 0; i < h; i++)
                cout << " ";
            cout << "  \\\n";
            printTree_v2(r->left, h + 3);
        }
    }
}
void Post(Node* tree)
{
    if (tree != nullptr)
    {
        Post(tree->left);
        Post(tree->right);
        cout << tree->data << " ";
    }
}
int search(int arr[], int strt, int end, int value);
 
/* Recursive function to construct binary of size n
   from  Inorder traversal in[] and Postorder traversal
   post[].  Initial values of inStrt and inEnd should
   be 0 and n -1.  The function doesn't do any error
   checking for cases where inorder and postorder
   do not form a tree */
Node* buildUtil(int in[], int post[], int inStrt,
                int inEnd, int* pIndex)
{
    // Base case
    if (inStrt > inEnd)
        return NULL;
 
    /* Pick current node from Postorder traversal using
       postIndex and decrement postIndex */
    Node* node = new Node(post[*pIndex]);
    (*pIndex)--;
 
    /* If this node has no children then return */
    if (inStrt == inEnd)
        return node;
 
    /* Else find the index of this node in Inorder
       traversal */
    int iIndex = search(in, inStrt, inEnd, node->data);
 
    /* Using index in Inorder traversal, construct left and
       right subtress */
    node->right = buildUtil(in, post, iIndex + 1, inEnd, pIndex);
    node->left = buildUtil(in, post, inStrt, iIndex - 1, pIndex);
 
    return node;
}
 
// This function mainly initializes index of root
// and calls buildUtil()
Node* buildTree_inorder_postorder(int in[], int post[], int n)
{
    int pIndex = n - 1;
    return buildUtil(in, post, 0, n - 1, &pIndex);
}
 
/* Function to find index of value in arr[start...end]
   The function assumes that value is postsent in in[] */
int search(int arr[], int strt, int end, int value)
{
    int i;
    for (i = strt; i <= end; i++) {
        if (arr[i] == value)
            break;
    }
    return i;
}
void Inorder(Node* tree)
{
    if (tree != nullptr)
    {
        Inorder(tree->left);
        cout << tree->data << " ";
        Inorder(tree->right);
    }
}
int main()
{
    Node* tree = nullptr;
    int a[] = {39, 53, 20, 74, 58, 43, 82, 49, 97, 56};
    int b[] = {39, 20, 53, 58, 74, 49, 56, 97, 82, 43};
    tree = buildTree_inorder_postorder(a, b, sizeof(a) / sizeof(a[0]));
    printTree_v2(tree, 0);
    cout << endl;
    Inorder(tree);
    cout << endl;
    Post(tree);
}