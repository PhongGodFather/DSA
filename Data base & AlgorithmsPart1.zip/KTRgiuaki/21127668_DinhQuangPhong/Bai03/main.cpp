#include <iostream>
using namespace std;
void MergeA_B(int a[], int m, int b[], int n, int c[], int &d)
{
    d = m + n;
    int *p = a, *q = &b[n - 1];
    for (int i = 0; i < d; i += 2, p++, q--)
    {
        if (*p >= *q)
        {
            c[i] = *p;
            c[i + 1] = *q;
        }
        else
        {
            c[i] = *q;
            c[i + 1] = *p;
        }
    }
}
int main()
{
    int a[] = {100, 50, 25, 15, 5, 0};
    int m = sizeof(a) / sizeof(a[0]);
    int b[] = {1, 3, 6, 7, 99, 101};
    int n = sizeof(b) / sizeof(b[0]);
    int c[100], sizec;
    MergeA_B(a, m, b, n, c, sizec);
    for (int i = 0; i < sizec; i++)
        cout << c[i] << " ";
}