#include <iostream>
#include <time.h>
using namespace std;
int Partition(int a[], int l, int h)
{
    int pivot = a[h],left = l,right = h - 1;
    while (true) 
    {
        while (left <= right && a[left] > pivot) 
            left++;
        while (right >= left && a[right] < pivot) 
            right--;
        if (left >= right) 
            break;
        swap(a[left], a[right]);
        left++;
        right--;
    }
    swap(a[left], a[h]);
    return left;
}
void QuickSort(int a[], int l, int h)
{
    if (l < h)
    {
        int pi = Partition(a, l, h);
        QuickSort(a, l, pi - 1);
        QuickSort(a, pi + 1, h);
    }
}
void Merge(int a[], int l, int m, int r)
{
    int i, j, k;
    int n1 = m - l + 1;
    int n2 = r - m;
    int* L = new int[n1];
    int* R = new int[n2];
    for (i = 0; i < n1; i++)
        L[i] = a[l + i];
    for (j = 0; j < n2; j++)
        R[j] = a[m + 1 + j];
    i = 0;
    j = 0;
    k = l;
    while (i < n1 && j < n2)
    {
        if (L[i] >= R[j])
        {
            a[k] = L[i];
            i++;
        }
        else
        {
            a[k] = R[j];
            j++;
        }
        k++;
    }
    while (i < n1)
    {
        a[k] = L[i];
        i++;
        k++;
    }
    while (j < n2)
    {
        a[k] = R[j];
        j++;
        k++;
    }
}
void MergeSort(int a[], int l, int r)
{
    if (l < r)
    {
        int m = l + (r - l) / 2;
        MergeSort(a, l, m);
        MergeSort(a, m + 1, r);
        Merge(a, l, m, r);
    }
}
int main()
{
    int a[100];
    srand((unsigned int)time(NULL));
    for (int i = 0; i < 100; i++)
        a[i] = rand();
    cout << "Before: ";
    for (int i = 0; i < 100; i++)
        cout << a[i] << " ";
    cout << endl;
    QuickSort(a, 0, 99);
    //MergeSort(a, 0, 99); remove this when need to use MergeSort algorithm
    cout << "After: ";
    for (int i = 0; i < 100; i++)
        cout << a[i] << " ";
}