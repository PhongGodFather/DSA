#include <iostream>
using namespace std;
struct Node
{
    int data;
    Node *next;
    Node(int key)
    {
        data = key;
        next = nullptr;
    }
};
void append(Node *&list, int key)
{
    if (list == nullptr)
        list = new Node(key);
    else
        append(list->next, key);
}
void PrintList(Node *a)
{
    for (auto i = a; i; i = i->next)
        cout << i->data << " ";
}
void sortedInsert(Node *&sorted, Node *newnode)
{
    if (sorted == NULL || sorted->data >= newnode->data)
    {
        newnode->next = sorted;
        sorted = newnode;
    }
    else
    {
        Node *current = sorted;
        while (current->next != NULL && current->next->data < newnode->data)
            current = current->next;
        newnode->next = current->next;
        current->next = newnode;
    }
}
void insertionSort(Node *&head)
{
    Node *sorted = nullptr;
    Node *current = head;
    while (current != NULL)
    {
        Node *next = current->next;    // this one is very important not stupid or waste, used to stored the link of the current
        sortedInsert(sorted, current); // because current will be changed in this function and its link will be deleted or changed
        current = next;
    }
    head = sorted;
}
int main()
{
    Node *a = nullptr;
    append(a, 3);
    append(a, 10);
    append(a, 5);
    append(a, 1);
    append(a, -3423);
    cout << "Before : ";
    PrintList(a);
    insertionSort(a);
    cout << "\nAfter : ";
    PrintList(a);
}