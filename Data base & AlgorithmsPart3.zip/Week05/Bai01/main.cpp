#include <iostream>
using namespace std;
struct Node
{
    int data;
    Node *next;
    Node(int key)
    {
        data = key;
        next = nullptr;
    }
};
void removeEnd(Node *&list)
{
    if (list == nullptr)
        return;
    if (list->next == nullptr)
    {
        list = nullptr;
        return;
    }
    else
    {
        Node *temp = list;
        Node *temp1 = nullptr;
        while (temp->next != nullptr)
        {
            temp1 = temp;
            temp = temp->next;
        }
        temp1->next = temp->next;
        temp->next = nullptr;
        delete temp->next;
    }
}
void append(Node *&head, int n)
{
    if (head == NULL)
        head = new Node(n);
    else
        append(head->next, n);
}
template <class T>
struct Stack
{
    Node *a;
    T Top()
    {
        Node *i = a;
        while (i->next != nullptr)
            i = i->next;
        return i->data;
    }
    Stack() { a = nullptr; }
    void push(int stuff) { append(a, stuff); }
    bool isEmpty() { return (a == nullptr); }
    void pop()
    {
        if (isEmpty())
            return;
        removeEnd(a);
    }
};
void PrintStack(Stack<int> S)
{
    Stack<int> temp = S;
    while (!temp.isEmpty())
    {
        cout << temp.Top() << " ";
        temp.pop();
    }
    cout << endl;
}
int main()
{
    Stack<int> ok;
    ok.push(123);
    ok.push(234);
    ok.push(67);
    PrintStack(ok);
}