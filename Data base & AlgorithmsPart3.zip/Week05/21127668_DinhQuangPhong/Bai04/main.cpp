#include <iostream>
using namespace std;
struct Node
{
	int data;
	Node* next, * prev;
    Node(int key)
    {
        data = key;
        next = NULL;
    }
};
void append(Node*& list, int key)
{
    Node* newnode = new Node(key);
    if (list == NULL)
    {
        newnode->prev = NULL;
        list = newnode;
    }
    else
    {
        Node* last = list;
        while (last->next != NULL)
            last = last->next;
        last->next = newnode;
        newnode->prev = last;
    }
}
void showNormal(Node* list)
{
    for (auto i = list; i; i = i->next)
        cout << i->data << " ";
}
void showReverse(Node* list)
{
    Node* last = list;
    while (last->next != NULL)
        last = last->next;
    for (auto i = last; i; i = i->prev)
        cout << i->data << " ";
}
void SortedInsert(Node*& sorted, Node* current)
{
    if (sorted == NULL)
        sorted = current;
    else if (sorted->data >= current->data)
    {
        current->next = sorted;
        current->next->prev = current;
        sorted = current;
    }
    else
    {
        Node* temp = sorted;
        while (temp->next != NULL && temp->next->data < current->data)
            temp = temp->next;
        current->next = temp->next;
        if (temp->next != NULL)
            current->next->prev = current;
        current->prev = temp;
        temp->next = current;
    }
}
void InsertionSort(Node*& list)
{
    Node* sorted = NULL;
    Node* last_current = list;
    while (last_current->next != NULL)
        last_current = last_current->next;
    while (last_current != NULL)
    {
        Node* previous = last_current->prev;
        SortedInsert(sorted, last_current);
        last_current = previous;
    }
    list = sorted;
    list->prev = NULL;
}
int main()
{
    Node* list = NULL;
    append(list, 12);
    append(list, 245);
    append(list, 1);
    append(list, 90);
    cout << "Before: ";
    showNormal(list);
    InsertionSort(list);
    cout << "\nAfter: ";
    showNormal(list);
}