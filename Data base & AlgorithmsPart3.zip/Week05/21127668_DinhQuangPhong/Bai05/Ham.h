#pragma once
#ifndef Ham
#define Ham
#include <iostream>
#include <string>
using namespace std;
struct SinhVien
{
	char name[50];
	int math, physic, chemist;
};
struct Node
{
	SinhVien data;
	int average;
	Node* next;
	Node(SinhVien key)
	{
		data = key;
		average = (key.math + key.chemist + key.physic) / 3;
		next = NULL;
	}
};
class Student_management
{
public:
	Node* list;
	int list_size = 0;
	Student_management() { list = NULL; };
	void append(SinhVien key);
	SinhVien new_student();
	void show();
	void read_file();
	void write_file();
	void delete_at(int n);
	void delete_same_name();
	void search();
	void insert_end();
	void insert_before_first();
	void insert_after_first();
	void insert_after_name(string name);
	void top_k_students(int n);
};
#endif // !Ham
