#include "Ham.h"
#include <fstream>
void insertionSort(int a[], int n)
{
	for (int i = 1; i < n; i++)
	{
		int temp = a[i];
		for (int j = i - 1; j >= 0 && temp > a[j]; j--)
		{
			a[j + 1] = a[j];
			a[j] = temp;
		}
	}
}
bool is_equal(string a, string b)
{
	for (int i = 0; i < a.length(); i++)
		if (a[i] != b[i])
			return false;
	return true;
}
void Student_management::append(SinhVien key)
{
	list_size++;
	if (list == NULL)
		list = new Node(key);
	else
	{
		Node* temp = list;
		while (temp->next != NULL)
			temp = temp->next;
		temp->next = new Node(key);
	}
}
SinhVien Student_management::new_student()
{
	SinhVien a;
	cin.ignore();
	cout << "\nNew student info register \n";
	cout << "Name: ";
	cin.getline(a.name, 50);
	int n;
	cout << "Math: ";
	cin >> n;
	a.math = n;
	cout << "Physic: ";
	cin >> n;
	a.physic = n;
	cout << "Chemist: ";
	cin >> n;
	a.chemist = n;
	return a;
}
void Student_management::show()
{
	cout << endl;
	printf("%-19s %-10s %-10s %-10s %s\n", "Name", "Math", "Physic", "Chemist", "Average");
	for (auto i = list; i; i = i->next)
		printf("%-20s %-10d %-10d %-10d %d\n", i->data.name, i->data.math, i->data.physic, i->data.chemist, i->average);
}
void Student_management::read_file()
{
	fstream file("sinhvien.txt", ios::in | ios::binary);
	if (file.fail())
		return;
	int n;
	file.read((char*)&n, sizeof(n));
	for (int i = 0; i < n; i++)
	{
		SinhVien a;
		file.read((char*)&a, sizeof(SinhVien));
		append(a);
	}
	file.close();
}
void Student_management::write_file()
{
	fstream file("sinhvien.txt", ios::out | ios::binary);
	file.write((char*)&list_size, sizeof(list_size));
	for (auto i = list; i; i = i->next)
		file.write((char*)&i->data, sizeof(SinhVien));
	file.close();
}
void Student_management::delete_at(int n)
{
	if (list == NULL)
		return;
	Node* temp = list, * hold = NULL;
	if (n == 0)
	{
		list = list->next;
		delete temp;
		return;
	}
	if (n > list_size - 1)
		n = list_size - 1;
	while (n != 0)
	{
		hold = temp;
		temp = temp->next;
		n--;
	}
	hold->next = temp->next;
	delete temp;
}
void Student_management::delete_same_name()
{
	Node* temp = list;
	while (temp != NULL && temp->next != NULL)
	{
		Node* hold = temp;
		while (hold->next != NULL)
		{
			if (is_equal(temp->data.name, hold->next->data.name))
			{
				Node* dup = hold->next;
				hold->next = hold->next->next;
				delete dup;
			}
			else
				hold = hold->next;
		}
		temp = temp->next;
	}
}
void Student_management::search()
{
	cout << "1. Search by Full Name\n2. Search by Math score\n3. Search by Physic score\n4. Search by Chemist score\n";
	cout << "Your choice: ";
	int n;
	cin >> n;
	cin.ignore();
	if (n == 1)
	{
		cout << "Name: ";
		char k[50];
		cin.getline(k, 50);
		cout << endl;
		printf("%-19s %-10s %-10s %-10s %s\n", "Name", "Math", "Physic", "Chemist", "Average");
		for (auto i = list; i; i = i->next)
			if (is_equal(i->data.name, k))
				printf("%-20s %-10d %-10d %-10d %d\n", i->data.name, i->data.math, i->data.physic, i->data.chemist, i->average);
	}
	else if (n == 2)
	{
		cout << "Math score: ";
		cin >> n;
		printf("%-19s %-10s %-10s %-10s %s\n", "Name", "Math", "Physic", "Chemist", "Average");
		for (auto i = list; i; i = i->next)
			if (i->data.math == n)
				printf("%-20s %-10d %-10d %-10d %d\n", i->data.name, i->data.math, i->data.physic, i->data.chemist, i->average);
	}
	else if (n == 3)
	{
		cout << "Physic score: ";
		cin >> n;
		printf("%-19s %-10s %-10s %-10s %s\n", "Name", "Math", "Physic", "Chemist", "Average");
		for (auto i = list; i; i = i->next)
			if (i->data.physic == n)
				printf("%-20s %-10d %-10d %-10d %d\n", i->data.name, i->data.math, i->data.physic, i->data.chemist, i->average);
	}
	else
	{
		cout << "Chemist score: ";
		cin >> n;
		printf("%-19s %-10s %-10s %-10s %s\n", "Name", "Math", "Physic", "Chemist", "Average");
		for (auto i = list; i; i = i->next)
			if (i->data.chemist == n)
				printf("%-20s %-10d %-10d %-10d %d\n", i->data.name, i->data.math, i->data.physic, i->data.chemist, i->average);
	}
}
void Student_management::insert_end()
{
	SinhVien temp = new_student();
	append(temp);
}
void Student_management::insert_before_first()
{
	SinhVien temp = new_student();
	Node* k = new Node(temp);
	k->next = list;
	list = k;
}
void Student_management::insert_after_first()
{
	SinhVien temp = new_student();
	Node* k = new Node(temp);
	k->next = list->next;
	list->next = k;
}
void Student_management::insert_after_name(string name)
{
	SinhVien student = new_student();
	Node* temp = list, * hold = list;
	while (!is_equal(temp->data.name, name) && temp->next != NULL)
	{
		hold = temp->next;
		temp = temp->next;
	}
	if (temp->next == NULL)
		temp->next = new Node(student);
	else
	{
		Node* t = new Node(student);
		t->next = hold->next;
		hold->next = t;
	}
}
void Student_management::top_k_students(int n)
{
	cout << "\nTop " << n << " students: \n";
	if (n > list_size)
		n = list_size;
	int a[100], j = 0;
	for (auto i = list; i; i = i->next, j++)
		a[j] = i->average;
	insertionSort(a, j);
	int k = 0;
	printf("%-19s %-10s %-10s %-10s %s\n", "Name", "Math", "Physic", "Chemist", "Average");
	for (int k = 0; k < n; k++)
	{
		for (auto i = list; i; i = i->next)
			if (i->average == a[k])
			{
				printf("%-20s %-10d %-10d %-10d %d\n", i->data.name, i->data.math, i->data.physic, i->data.chemist, i->average);
				break;
			}
	}
}