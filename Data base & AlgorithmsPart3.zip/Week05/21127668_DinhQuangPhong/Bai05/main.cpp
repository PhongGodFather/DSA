#include "Ham.h"
void menu()
{
	cout << "\n======MENU======\n";
	cout << "1. Display list\n";
	cout << "2. Insert new student at end of list\n";
	cout << "3. Insert new student before first element\n";
	cout << "4. Insert new student after first element\n";
	cout << "5. Insert new student after specific name\n";
	cout << "6. Search for student info\n";
	cout << "7. Delete a student from list\n";
	cout << "8. Delete students with same name\n";
	cout << "9. Display top n students \n";
	cout << "10. Exit \n";
	cout << "Your choice: ";
}
int main()
{
	int n;
	Student_management a;
	a.read_file();
	do
	{
		menu();
		cin >> n;
		if (n == 1) a.show();
		else if (n == 2) a.insert_end();
		else if (n == 3) a.insert_before_first();
		else if (n == 4) a.insert_after_first();
		else if (n == 5)
		{
			char t[50];
			cin.ignore();
			cout << "\nEnter name to insert after: ";
			cin.getline(t, 50);
			a.insert_after_name(t);
		}
		else if (n == 6) a.search();
		else if (n == 7)
		{
			int temp;
			cout << "Enter the position to delete: ";
			cin >> temp;
			a.delete_at(temp);
		}
		else if (n == 8)
		{
			a.delete_same_name();
			cout << "\nDuplicated names cleared\n";
		}
		else if (n == 9)
		{
			int temp;
			cout << "Enter the number of students you want: ";
			cin >> temp;
			a.top_k_students(temp);
		}
		else
		{
			cout << "\nEND";
			a.write_file();
			break;
		}
	} while (true);
}