#include <iostream>
#include <cstdlib>
#include <ctime>
#include <Windows.h>
#include <Psapi.h>
using namespace std;
struct Node
{
	int data;
	Node *next;
	Node(int key)
	{
		data = key;
		next = nullptr;
	}
};
void append(Node *&list, int key)
{
	if (list == nullptr)
		list = new Node(key);
	else
		append(list->next, key);
}
void delete_front(Node *&list)
{
	Node *oldnode = list;
	list = list->next;
	delete oldnode;
}
template <class T>
struct Queue
{
	Node *a;
	T Front() { return a->data; }
	Queue() { a = nullptr; }
	void Enqueue(T stuff) { append(a, stuff); }
	bool isEmpty() { return (a == nullptr); }
	void Dequeue()
	{
		if (isEmpty())
			return;
		delete_front(a);
	}
};
void PrintQueue(Queue<int> q)
{
	auto temp = q;
	while (!temp.isEmpty())
	{
		cout << temp.Front() << " ";
		temp.Dequeue();
	}
}
int main()
{
	Queue<int> a;
	a.Enqueue(12);
	a.Enqueue(123);
	a.Enqueue(324);
	// PROCESS_MEMORY_COUNTERS_EX pmc;
	// GetProcessMemoryInfo(GetCurrentProcess(), (PROCESS_MEMORY_COUNTERS*)&pmc, sizeof(pmc));
	// SIZE_T virtualMemUsedByMe = pmc.PrivateUsage;
	// cout << "Used: " << virtualMemUsedByMe / 1024 << "KB" << endl;
	PrintQueue(a);
	cout << endl;
	return 0;
}