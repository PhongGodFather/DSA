#include "Ham.h"
int split(string temp)
{
	int count = 0;
	for (int i = temp.size() - 1; i > 0; i--)
	{
		if (temp[i] == ' ' || temp[i] == '\t')
			break;
		else
			count++;
	}
	return count;
}
long long strToInt(string number)
{
	int l1 = number.length();
	long long num1 = 0;
	for (int i = l1 - 1; i >= 0; --i)
		num1 += (int)(number[i] - '0') * pow(10, l1 - i - 1);
	return num1;
}
bool Hash::isFull()
{
	for (int i = 0; i < lines; i++)
		if (table[i].name == "")
			return false;
	return true;
}
int HashCode(string s)
{
	int sum = 0;
	for (int i = 0; i < s.length(); i++)
		sum += s[i];
	return sum;
}
int Hash::hashFunction(string s)
{
	int index = HashCode(s);
	return index % lines;
}
Hash::Hash(int b)
{
	this->lines = b;
	table = new monster[lines];
	for (int i = 0; i < lines; i++)
	{
		table[i].name = "";
		table[i].phone = 0;
	}
}
void Hash::insert(string name, long long phone)
{
	if (!isFull())
	{
		int index = hashFunction(name);
		while (table[index].name != "")
			index = (index + 1) % lines;
		table[index].name = name;
		table[index].phone = phone;
		return;
	}
	cout << "\nCannot insert " << name << " because the table is full !\n";
}
void Hash::Find(string name)
{
	for (int i = hashFunction(name), k = 0; k < lines; i = (i + 1) % lines, k++)
		if (table[i].name == name)
		{
			cout << table[i].phone << endl;
			return;
		}
	cout << name << " is not inside the phonebook\n" << endl;
}
void Hash::deleteMonster(string name)
{
	for (int i = hashFunction(name), k = 0; k < lines; i = (i + 1) % lines, k++)
		if (table[i].name == name)
		{
			table[i].name = "";
			table[i].phone = 0;
			return;
		}
	cout << name << " is not inside the phonebook\n";
}
void Hash::UpdateMonster(string name, long long newphone)
{
	for (int i = hashFunction(name), k = 0; k < lines; k++, i = (i + 1) % lines)
		if (table[i].name == name)
		{
			table[i].phone = newphone;
			return;
		}
	cout << name << " is not inside the phonebook \n";
}
void Hash::displayHash()
{
	for (int i = 0; i < lines; i++)
		if (table[i].name != "")
			cout << i << " --> " << table[i].name << " " << table[i].phone << endl;
		else
			cout << i << " --> \n";
}
string correctionName(string s)
{
	int i;
	for (i = 0; i < s.length(); i++)
	{
		if (i + 1 < s.length())
		{
			if (s[i] == ' ' && s[i + 1] == ' ' || s[i] == '\t' || s[i] == ' ' && s[i + 1] == '\t' || s[i] == ' '
				&& s[i+1] >= '0' && s[i+1] <= '9')
				break;
		}
	}
	return s.substr(0,i);
}
void Hash::readfile()
{
	fstream file("phonebook.txt", ios::in);
	string temp;
	while (getline(file, temp, '\n'))
	{
		string number;
		string name;
		number = temp.substr(temp.size() - split(temp));
		name = correctionName(temp);
		insert(name, strToInt(number));
	}
	file.close();
}