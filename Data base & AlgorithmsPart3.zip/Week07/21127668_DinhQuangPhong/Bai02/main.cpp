#include "Ham.h"
int main()
{
	Hash h(5);
	h.readfile();
	h.displayHash();
	cout << endl;
	h.Find("Dinh Quang Phong ");
	h.UpdateMonster("Dinh Quang Phong", 21127668);
	//h.deleteMonster("Dinh Quang Phong");
	cout << endl;
	h.displayHash();
}