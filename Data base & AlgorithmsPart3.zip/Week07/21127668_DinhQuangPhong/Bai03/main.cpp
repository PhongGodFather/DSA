#include "Ham.h"
int main()
{
	Hash h;
	h.readfile();
	h.displayHash();
	cout << endl;
	h.Find("Hugh Jackman");
	h.UpdateMonster("Dinh Quang Phong", 21127668);
	h.deleteMonster("Dinh Quang Phong");
	cout << endl;
	h.displayHash();
}