#pragma once
#ifndef Ham
#define Ham
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
struct monster
{
	string name;
	long long phone;
};
class Hash
{
	int lines, index;
	monster* table;
	int sizeList[400];
public:
	Hash();
	bool isFull();
	monster* NewTableSize();
	void insert(string name, long long phone);
	void deleteMonster(string name);
	void UpdateMonster(string name, long long newphone);
	void Find(string name);
	int hashFunction(string s);
	void displayHash();
	void readfile();
};
#endif // !Ham
