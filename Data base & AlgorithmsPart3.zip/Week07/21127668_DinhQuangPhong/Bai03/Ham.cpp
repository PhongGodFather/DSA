#include "Ham.h"
int split(string temp)
{
	int count = 0;
	for (int i = temp.size() - 1; i > 0; i--)
	{
		if (temp[i] == ' ' || temp[i] == '\t')
			break;
		count++;
	}
	return count;
}
long long strToInt(string number)
{
	int l1 = number.length();
	long long num1 = 0;
	for (int i = l1 - 1; i >= 0; --i)
		num1 += (int)(number[i] - '0') * pow(10, l1 - i - 1);
	return num1;
}
bool Hash::isFull()
{
	for (int i = 0; i < lines; i++)
		if (table[i].name == "")
			return false;
	return true;
}
int HashCode(string s)
{
	int sum = 0;
	for (int i = 0; i < s.length(); i++)
		sum += s[i];
	return sum;
}
int Hash::hashFunction(string s)
{
	int index = HashCode(s);
	return index % lines;
}
Hash::Hash()
{
	fstream file("phonebook.txt", ios::in);
	string temp;
	getline(file, temp, '\n');
	int k = 0;
	for (int i = 0; i < temp.length(); i++)
	{
		int sum = 0;
		while (temp[i] != ' ' && i < temp.length())
		{
			sum = sum * 10 + temp[i] - '0';
			i++;
		}
		sizeList[k++] = sum;
	}
	file.close();
	index = 0;
	this->lines = sizeList[index];
	table = new monster[sizeList[index]];
	for (int i = 0; i < lines; i++)
	{
		table[i].name = "";
		table[i].phone = 0;
	}
}
void Hash::insert(string name, long long phone)
{
	if (isFull())
		table = NewTableSize();
	int i = hashFunction(name);
	while (table[i].name != "")
		i = (i + 1) % lines;
	table[i].name = name;
	table[i].phone = phone;
}
void Hash::Find(string name)
{
	for (int i = hashFunction(name), k = 0; k < lines; i = (i + 1) % lines, k++)
		if (table[i].name == name)
		{
			cout << table[i].phone << endl;
			return;
		}
	cout << name << " is not inside the phonebook\n" << endl;
}
void Hash::deleteMonster(string name)
{
	for (int i = hashFunction(name), k = 0; k < lines; i = (i + 1) % lines, k++)
		if (table[i].name == name)
		{
			table[i].name = "";
			table[i].phone = 0;
			return;
		}
	cout << name << " is not inside the phonebook\n";
}
void Hash::UpdateMonster(string name, long long newphone)
{
	for (int i = hashFunction(name), k = 0; k < lines; k++, i = (i + 1) % lines)
		if (table[i].name == name)
		{
			table[i].phone = newphone;
			return;
		}
	cout << name << " is not inside the phonebook \n";
}
void Hash::displayHash()
{
	for (int i = 0; i < lines; i++)
		if (table[i].name != "")
			cout << i << " --> " << table[i].name << " " << table[i].phone << endl;
		else
			cout << i << " --> \n";
}
string correctionName(string s)
{
	int i;
	for (i = 0; i < s.length(); i++)
	{
		if (i + 1 < s.length())
		{
			if (s[i] == ' ' && s[i + 1] == ' ' || s[i] == '\t' || s[i] == ' ' && s[i + 1] == '\t' || s[i] == ' '
				&& s[i + 1] >= '0' && s[i + 1] <= '9')
				break;
		}
	}
	return s.substr(0, i);
}
void Hash::readfile()
{
	fstream file("phonebook.txt", ios::in);
	string temp, firstline;
	getline(file, firstline, '\n');
	while (getline(file, temp, '\n'))
	{
		string t1;
		string t2;
		t1 = temp.substr(temp.size() - split(temp));
		t2 = correctionName(temp);
		insert(t2, strToInt(t1));
	}
	file.close();
}
monster* Hash::NewTableSize()
{
	int oldlines = lines;
	index++;
	monster *newTable = new monster[sizeList[index]];
	lines = sizeList[index];
	for (int i = 0; i < oldlines; i++)
		newTable[i] = table[i];
	return newTable;
}