#include "Ham.h"
bool isPrime(int n)
{
	for (int i = 2; i <= n / 2; i++)
		if (n % 2 == 0)
			return false;
	//cout <<" SNT: " << n << " " << endl;
	return true;
}
Hash::Hash(int b)
{
	this->lines = b;
	table = new vector<int>[b];
}
void Hash::insertChaining(int key)
{
	int index = hashFunction(key);
	table[index].push_back(key);
}
bool Hash::searchChaining(int key)
{
	int index = hashFunction(key);
	for (auto x : table[index])
		if (x == key)
			return true;
	return false;
}
void Hash::insertLinear(int x)
{
	int index = hashFunction(x);
	if (table[index].empty())
		table[index].push_back(x);
	else
	{
		while (!table[index].empty())
			index = (index + 1) % lines;
		table[index].push_back(x);
	}
}
bool Hash::searchLinear(int key)
{
	int index = hashFunction(key);
	for (int i = index; i < lines; i++)
	{
		auto x = table[i];
		if (*x.begin() == key)
			return true;
	}
	return false;
}
void Hash::insertQuadratic(int x)
{
	int index = hashFunction(x);
	if (table[index].empty())
		table[index].push_back(x);
	else
	{
		for (int i = 1; (i * i + index) < lines; ++i)
		{
			if (table[index + i * i].empty())
			{
				table[index + i * i].push_back(x);
				return;
			}
		}
	}
}
bool Hash::searchQuadratic(int key)
{
	int index = hashFunction(key);
	if (*table[index].begin() == key)
		return true;
	else
	{
		for (int i = 1; (i * i + index) < lines; ++i)
		{
			if (*table[index + i * i].begin() == key)
				return true;
		}
	}
	return false;
}
//void Hash::insertDoubleHash(int x)
//{
//	int prime = lines - 1;
//	while (!isPrime(prime))
//		prime--;
//	int index = hashFunction(x);
//	if (table[index].empty())
//		table[index].push_back(x);
//	else
//	{
//		int i = 1;
//		while (!table[index].empty())
//		{
//			index = (hashFunction(x) + i * hashFunction2(x, prime)) % lines;
//			if (table[index].empty())
//			{
//				table[index].push_back(x);
//				return;
//			}
//			i++;
//		}
//	}
//}
void Hash::insertDoubleHash(int x)
{
	int index1 = hashFunction(x);
	if (table[index1].empty())
	{
		table[index1].push_back(x);
		return;
	}
	vector<int> prime_temp;
	int num = 0;
	for (int i = x; i >= 2; i--)
	{
		if (isPrime(i))
			prime_temp.push_back(i);
	}
	for (auto j = prime_temp.end(); j != prime_temp.begin(); --j)
	{
		int index2 = *j - (x % *j);
		for (int j = 1; ((index1 + j * index2) % lines) < lines; j++)
		{
			if (table[j].empty())
			{
				table[j].push_back(x);
				return;
			}
		}
	}
}
bool Hash::searchDoubleHash(int key)
{
	int prime = lines - 1;
	while (!isPrime(prime))
		prime--;
	int index = hashFunction(key);
	if (*table[index].begin() == key)
		return true;
	else
	{
		int i = 1;
		while (!table[index].empty())
		{
			index = (hashFunction(key) + i * hashFunction2(key, prime)) % lines;
			if (*table[index].begin() == key)
				return true;
			i++;
			if (i > lines - 1)
				return false;
		}
		cout << index << endl;
		return false;
	}
}
void Hash::displayHash()
{
	for (int i = 0; i < lines; i++)
	{
		cout << i;
		for (auto x : table[i])
			cout << " --> " << x;
		cout << endl;
	}
}