#include "Ham.h"
int main()
{
    Hash table(5);
    /*table.insertChaining(134);
    table.insertChaining(43);
    table.insertChaining(65);
    cout << table.searchChaining(134) << endl;*/

    /*table.insertLinear(10);
    table.insertLinear(20);
    table.insertLinear(30);
    table.insertLinear(15);
    table.insertLinear(16);
    table.insertLinear(25);
    cout << table.searchLinear(25) << endl;*/

    /*table.insertQuadratic(213);
    table.insertQuadratic(43);
    table.insertQuadratic(668);
    cout << table.searchQuadratic(43) << endl;*/

    table.insertDoubleHash(4);
    table.insertDoubleHash(11);
    table.insertDoubleHash(29);
    table.insertDoubleHash(1);
    table.insertDoubleHash(5);
    //cout << table.searchDoubleHash(22) << endl; // need fixing
    table.displayHash();
}