#pragma once
#ifndef Ham
#define Ham
#include <vector>
#include <iostream>
using namespace std;
class Hash
{
    int lines;
    vector<int>* table;

public:
    Hash(int V);
    void insertChaining(int x);
    bool searchChaining(int key);
    void insertLinear(int x);
    bool searchLinear(int key);
    int hashFunction(int x) { return (x % lines); }
    int hashFunction2(int x, int prime) { return prime - x % prime; }
    void insertQuadratic(int x);
    bool searchQuadratic(int key);
    void displayHash();
    void insertDoubleHash(int x);
    bool searchDoubleHash(int key);

};
#endif // !Ham
