#include <iostream>
#include <string>
#include <fstream>
using namespace std;
struct Node 
{
	int key;
	Node* left, * right;
	Node(int data) 
	{
		key = data;
		left = right = NULL;
	}
};
void insert(Node*& r, int key) {
	if (r == nullptr) {
		r = new Node(key);
	}
	else {
		if (r->key == key) return;
		if (r->key > key)
			insert(r->left, key);
		if (r->key < key)
			insert(r->right, key);
	}
}
int height(Node* root)
{
	if (root == NULL)
		return 0;
	return 1 + max(height(root->left), height(root->right));
}
bool isBalanced(Node* tree)
{
	if (tree == NULL)
		return true;
	if (abs(height(tree->left) - height(tree->right)) <= 1 && isBalanced(tree->left) && isBalanced(tree->right))
		return true;
	return false;
}
void CHECK_BALANCE()
{
	fstream file("Input.txt", ios::in);
	fstream file_out("Output.txt", ios::out);
	char t;
	int n, k;
	file >> n;
	for (int i = 0; i < n; i++)
	{
		Node* tree = NULL;
		while (!file.eof())
		{	
			file >> k;
			t = file.get();
			insert(tree, k);
			if (t == '\n')
				break;
		}
		if (isBalanced(tree)) file_out << "yes\n";
		else file_out << "no\n";
	}
	file.close();
	file_out.close();
	cout << " FINISHED ";
}
int main()
{
	CHECK_BALANCE();
}