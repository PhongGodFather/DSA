#include "Ham.h"
int main()
{
	AVL tree;
	tree.insert(13);
	tree.insert(323);
	tree.insert(23);
	tree.insert(34);
	tree.insert(45);
	tree.insert(32);
	tree.insert(243);
	tree.insert(10);
	tree.printTree_v2();
	cout << tree.LeastCommon(323, 10);
}