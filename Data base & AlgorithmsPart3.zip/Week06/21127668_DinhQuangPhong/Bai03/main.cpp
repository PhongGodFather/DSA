#include "Ham.h"
int main()
{
	AVL tree;
	tree.insert(58);
	tree.insert(76);
	tree.insert(73);
	tree.insert(86);
	tree.insert(345);
	tree.insert(12);
	tree.insert(60);

	tree.insert(1000);

	tree.printTree_v2();
	if (tree.Check())
		cout << "The depth of the tree branch are the same";
	else cout << "The depth of the tree branch are not the same";
}