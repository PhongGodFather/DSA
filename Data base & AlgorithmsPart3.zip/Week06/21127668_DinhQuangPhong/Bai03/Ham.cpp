#include "Ham.h"
bool AVL::Check(Node* tree, int level, int& leafLevel)
{
    if (tree == NULL) return true;
    if (tree->left == NULL && tree->right == NULL)
    {
        if (leafLevel == 0)
        {
            leafLevel = level;
            return true;
        }
        return (level == leafLevel);
    }
    return Check(tree->left, level + 1, leafLevel) && Check(tree->right, level + 1, leafLevel);
}
void AVL::printTree_v2(Node* tree, int h)
{
    Node* r = tree;
    if (r == nullptr)
        return;
    else
    {
        if (r->right)
            printTree_v2(r->right, h + 3);
        for (int i = 0; i < h; i++)
            cout << " ";
        cout << " ";
        if (r->right)
        {
            cout << " /\n";
            for (int i = 0; i < h; i++)
                cout << " ";
            cout << " ";
        }
        cout << r->data << "\n ";
        if (r->left)
        {
            for (int i = 0; i < h; i++)
                cout << " ";
            cout << "  \\\n";
            printTree_v2(r->left, h + 3);
        }
    }
}
int AVL::height(Node* r)
{
    if (r == nullptr)
        return 0;
    return r->height;
}
Node* AVL::leftRotate(Node*& avl)
{
    Node* x = avl->right;
    avl->right = x->left;
    x->left = avl;
    avl->height = max(height(avl->left), height(avl->right)) + 1;
    x->height = max(height(x->left), avl->height) + 1;
    avl = x;
    return avl;
}
Node* AVL::rightRotate(Node*& avl)
{
    Node* x = avl->left;
    avl->left = x->right;
    x->right = avl;
    avl->height = max(height(avl->left), height(avl->right)) + 1;
    x->height = max(height(x->left), avl->height) + 1;
    avl = x;
    return avl;
}
int AVL::getBalance(Node* avl)
{
    if (avl == nullptr)
        return 0;
    return height(avl->left) - height(avl->right);
}
Node* AVL::insertNode(Node*& avl, int key)
{
    if (avl == nullptr)
        return new Node(key);
    else
    {
        if (avl->data == key)
            return avl;
        if (avl->data < key)
            avl->right = insertNode(avl->right, key);
        if (avl->data > key)
            avl->left = insertNode(avl->left, key);
        avl->height = 1 + max(height(avl->left), height(avl->right));
        int balance = getBalance(avl);
        if (balance > 1 && key < avl->left->data)
            return rightRotate(avl);
        if (balance < -1 && key > avl->right->data)
            return leftRotate(avl);
        if (balance > 1 && key > avl->left->data)
        {
            avl->left = leftRotate(avl->left);
            return rightRotate(avl);
        }
        if (balance < -1 && key < avl->right->data)
        {
            avl->right = rightRotate(avl->right);
            return leftRotate(avl);
        }
        return avl;
    }
}