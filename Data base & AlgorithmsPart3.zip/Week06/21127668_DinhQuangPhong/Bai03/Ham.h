#pragma once
#ifndef Ham
#define Ham
#include <iostream>
using namespace std;
struct Node
{
	int data;
	int height;
	Node* left, * right;
	Node(int key)
	{
		height = 1;
		data = key;
		left = right = nullptr;
	}
};
class AVL
{
public:
	Node* root;
	AVL() { root = nullptr; }
	void printTree_v2(Node* tree, int h);
	void printTree_v2() { printTree_v2(root, 0); }
	int height(Node* r);
	Node* leftRotate(Node*& avl);
	Node* rightRotate(Node*& avl);
	int getBalance(Node* avl);
	Node* insertNode(Node*& avl, int key);
	void insert(int key) { root = insertNode(root, key); }
	bool Check(Node* tree, int level, int& leafLevel);
	bool Check() { int temp = 0;  return Check(root, 0, temp); }
};
#endif // !Ham
