#pragma once
#ifndef Ham
#define Ham
struct Node
{
    int data;
    int height;
    Node* left, * right;
    Node(int key)
    {
        height = 1;
        data = key;
        left = right = nullptr;
    }
};
class AVL
{
public:
    Node* root;
    AVL() { root = nullptr; }
    void printTree(Node* tree, int h);
    void printTree() { printTree(root, 0); }
    void printTree_v2(Node* tree, int h);
    void printTree_v2() { printTree_v2(root, 0); }
    int height(Node* r);
    // Interface
    int treeHeight() { return height(root); }
    Node* leftRotate(Node*& avl);
    Node* rightRotate(Node*& avl);
    Node* doubleLeftRotate(Node*& avl);
    Node* doubleRightRotate(Node*& avl);
    int getBalance(Node* avl);
    Node* insertNode(Node*& avl, int key);
    // Interface
    void insert(int key) { root = insertNode(root, key); }
    Node* minValueNode(Node* node);
    Node* deleteNode(Node* tree, int key);
    void deleteTree(int key) { deleteNode(root, key); }
    bool check_exist(Node* tree, int key);
    // Interface
    bool check(int key) { return check_exist(root, key); }
    void PreOrder(Node* tree);
    // Interface
    void PreOrder() { PreOrder(root); }
    void InOrder(Node* tree);
    // Interface
    void InOrder() { InOrder(root); }
    void PostOrder(Node* tree);
    // Interface
    void PostOrder() { PostOrder(root); }
};
#endif // !Ham
