#include <iostream>
#include "Ham.h"
using namespace std;
int main()
{
    AVL tree;
    tree.insert(4);
    tree.insert(3);
    tree.insert(5);
    tree.insert(1);
    tree.insert(2);
    tree.insert(7);
    tree.insert(9);
    tree.insert(8);
    tree.insert(15);
    tree.insert(11);
    tree.insert(12);
    tree.insert(16);
    cout << "PreOrder traversal: ";
    tree.PreOrder();
    cout << "\nInOrder traversal: ";
    tree.InOrder();
    cout << "\nPostOrder traversal: ";
    tree.PostOrder();
    cout << endl;
    tree.printTree_v2();
    int a = 100, b = 15;
    cout << "Delete 12 and 9 from the tree: \n";
    tree.deleteTree(12);
    tree.deleteTree(9);
    tree.printTree_v2();
    if (tree.check(a)) cout << "\n"<<a<<" is exist\n";
    else cout << "\n"<<a<<" is not exist\n";
    if (tree.check(b)) cout << b << " is exist\n";
    else cout << b << " is not exist\n";
    cout <<"The tree height is "<< tree.treeHeight() << endl;
}