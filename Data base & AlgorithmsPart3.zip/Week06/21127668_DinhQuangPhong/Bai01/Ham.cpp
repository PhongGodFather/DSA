#include "Ham.h"
#include <iostream>
using namespace std;
void AVL::printTree(Node* tree, int h)
{
    Node* r = tree;
    if (r == nullptr)
    {
        for (int i = 0; i < h; i++)
            cout << "   ";
        cout << "*" << endl;
    }
    else
    {
        printTree(r->right, h + 1);
        for (int i = 0; i < h; i++)
            cout << "   ";
        cout << r->data << endl;
        printTree(r->left, h + 1);
    }
}
void AVL::printTree_v2(Node* tree, int h)
{
    Node* r = tree;
    if (r == nullptr)
        return;
    else
    {
        if (r->right)
            printTree_v2(r->right, h + 3);
        for (int i = 0; i < h; i++)
            cout << " ";
        cout << " ";
        if (r->right)
        {
            cout << " /\n";
            for (int i = 0; i < h; i++)
                cout << " ";
            cout << " ";
        }
        cout << r->data << "\n ";
        if (r->left)
        {
            for (int i = 0; i < h; i++)
                cout << " ";
            cout << "  \\\n";
            printTree_v2(r->left, h + 3);
        }
    }
}
int AVL::height(Node* r)
{
    if (r == nullptr)
        return 0;
    return r->height;
}
Node* AVL::leftRotate(Node*& avl)
{
    Node* x = avl->right;
    avl->right = x->left;
    x->left = avl;
    avl->height = max(height(avl->left), height(avl->right)) + 1;
    x->height = max(height(x->left), avl->height) + 1;
    avl = x;
    return avl;
}
Node* AVL::rightRotate(Node*& avl)
{
    Node* x = avl->left;
    avl->left = x->right;
    x->right = avl;
    avl->height = max(height(avl->left), height(avl->right)) + 1;
    x->height = max(height(x->left), avl->height) + 1;
    avl = x;
    return avl;
}
Node* AVL::doubleLeftRotate(Node*& avl)
{
    avl->left = leftRotate(avl->left);
    return rightRotate(avl);
}
Node* AVL::doubleRightRotate(Node*& avl)
{
    avl->right = rightRotate(avl->right);
    return leftRotate(avl);
}
int AVL::getBalance(Node* avl)
{
    if (avl == nullptr)
        return 0;
    return height(avl->left) - height(avl->right);
}
Node* AVL::insertNode(Node*& avl, int key)
{
    if (avl == nullptr)
        return new Node(key);
    else
    {
        if (avl->data == key)
            return avl;
        if (avl->data < key)
            avl->right = insertNode(avl->right, key);
        if (avl->data > key)
            avl->left = insertNode(avl->left, key);
        avl->height = 1 + max(height(avl->left), height(avl->right));
        int balance = getBalance(avl);
        if (balance > 1 && key < avl->left->data)
            return rightRotate(avl);
        if (balance < -1 && key > avl->right->data)
            return leftRotate(avl);
        if (balance > 1 && key > avl->left->data)
            return doubleLeftRotate(avl);
        if (balance < -1 && key < avl->right->data)
            return doubleRightRotate(avl);
        return avl;
    }
}
Node* AVL::minValueNode(Node* node)
{
    Node* current = node;
    while (current->left != NULL)
        current = current->left;
    return current;
}
Node* AVL::deleteNode(Node* root, int key)
{
    if (root == NULL)
        return root;
    if (key < root->data)
        root->left = deleteNode(root->left, key);
    else if (key > root->data)
        root->right = deleteNode(root->right, key);
    else
    {
        if ((root->left == NULL) ||
            (root->right == NULL))
        {
            Node* temp = root->left ? root->left : root->right;
            if (temp == NULL)
            {
                temp = root;
                root = NULL;
            }
            else
                *root = *temp;
            delete temp;
        }
        else
        {
            Node* temp = minValueNode(root->right);
            root->data = temp->data;
            root->right = deleteNode(root->right, temp->data);
        }
    }
    if (root == NULL)
        return root;
    root->height = 1 + max(height(root->left), height(root->right));
    int balance = getBalance(root);
    if (balance > 1 && getBalance(root->left) >= 0)
        return rightRotate(root);
    if (balance > 1 && getBalance(root->left) < 0)
    {
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }
    if (balance < -1 && getBalance(root->right) <= 0)
        return leftRotate(root);
    if (balance < -1 && getBalance(root->right) > 0)
    {
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }
    return root;
}
bool AVL::check_exist(Node* tree, int key)
{
    if (tree == NULL)
        return false;
    else
    {
        if (key == tree->data)
            return true;
        if (key > tree->data)
            return check_exist(tree->right, key);
        if (key < tree->data)
            return check_exist(tree->left, key);
        return false;
    }
}
void AVL::PreOrder(Node* tree)
{
    if (tree == NULL)
        return;
    else
    {
        cout << tree->data << " ";
        PreOrder(tree->left);
        PreOrder(tree->right);
    }
}
void AVL::InOrder(Node* tree)
{
    if (tree == NULL)
        return;
    else
    {
        InOrder(tree->left);
        cout << tree->data << " ";
        InOrder(tree->right);
    }
}
void AVL::PostOrder(Node* tree)
{
    if (tree == NULL)
        return;
    else
    {
        PostOrder(tree->left);
        PostOrder(tree->right);
        cout << tree->data << " ";
    }
}