#include "Ham.h"
Graph::Graph()
{
	fstream file("input.txt", ios::in);
	file >> cities >> roads >> c_lib >> c_road;
	while (!file.eof())
	{
		int city1, city2;
		file >> city1 >> city2;
		addEdge(city1, city2);
	}
	file.close();
}
void Graph::addEdge(int a, int b)
{
	addVertex(a);
	addVertex(b);
	roadList[a].insert(b);
	roadList[b].insert(a);
}
void Graph::printRoad()
{
	for (auto i : cityList)
	{
		cout << i << " : ";
		for (auto j : roadList[i])
			cout << "\n<-->" << j;
		cout << endl;
	}
}
int must_visitCity(vector<bool>& visited, map<int,set<int>> road, int s)
{
	visited[s] = 1;
	int sum = 1;
	for (auto i : road[s])
		if (visited[i] == 0)
			sum += must_visitCity(visited, road, i);
	return sum;
}
int Graph::minCost()
{
	int sum = 0;
	vector<bool> visited(cities + 1,0);
	for (int i = 0; i < cities; i++)
	{
		if (visited[i] == 0)
		{
			int n = must_visitCity(visited, roadList, i);
			sum += c_lib + (n - 1) * (min(c_lib, c_road));
		}
	}
	return sum - 2;
}