#pragma once
#ifndef Ham
#define Ham
#include <iostream>
#include <fstream>
#include <vector>
#include <set>
#include <map>
using namespace std;
class Graph
{
private:
	int cities, roads, c_lib, c_road;
	set<int> cityList;
	map<int, set<int>> roadList;
public:
	Graph();
	void addVertex(int v) { cityList.insert(v); }
	void addEdge(int a, int b);
	void printRoad();
	int getDegree(int x) { return roadList[x].size(); }
	int minCost();
};
#endif // !Ham
