#include "Ham.h"
int main()
{
	Graph temp;
	temp.printRoad();
	cout << "Min cost to build: " << temp.minCost();
}