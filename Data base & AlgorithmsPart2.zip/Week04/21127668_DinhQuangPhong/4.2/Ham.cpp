#include "Ham.h"
int toInt(string a)
{
	int sum = 0;
	for (int i = 0; i < a.length(); i++)
		sum = sum * 10 + a[i] - '0';
	return sum;
}
void insert(Node *&student, string id, string name, string birthday, bool status)
{
	Node *r = student;
	if (student == NULL)
		student = new Node(id, name, birthday, status);
	else
	{
		if (r->ID == id)
			return;
		if (toInt(id) < toInt(r->ID))
			insert(r->left, id, name, birthday, status);
		else
			insert(r->right, id, name, birthday, status);
	}
}
void out_info(Node *student)
{
	cout << student->ID << " " << student->Name << " " << student->Birthday << " " << student->Status << endl;
}
void search_id(Node *student, string id)
{
	if (student != nullptr)
	{
		if (student->ID == id)
			out_info(student);
		search_id(student->left, id);
		search_id(student->right, id);
	}
}
Node *minValueNode(Node *node)
{
	Node *current = node;
	while (current && current->left != NULL)
		current = current->left;
	return current;
}
Node *delete_id(Node *&student, string id)
{
	if (student == NULL)
		return student;
	if (toInt(id) < toInt(student->ID))
		student->left = delete_id(student->left, id);
	else if (toInt(id) > toInt(student->ID))
		student->right = delete_id(student->right, id);
	else
	{
		if (student->left == NULL && student->right == NULL)
			return NULL;
		else if (student->left == NULL)
		{
			Node *temp = student->right;
			delete student;
			return temp;
		}
		else if (student->right == NULL)
		{
			Node *temp = student->left;
			delete student;
			return temp;
		}
		Node *temp = minValueNode(student->right);
		student->ID = temp->ID;
		student->right = delete_id(student->right, temp->ID);
	}
	return student;
}
void printTree(Node *tree, int h)
{
	Node *r = tree;
	if (r == nullptr)
	{
		for (int i = 0; i < h; i++)
			cout << "   ";
		cout << "*" << endl;
	}
	else
	{
		printTree(r->right, h + 1); // right branch created first
		for (int i = 0; i < h; i++)
			cout << "   ";
		cout << r->Name << endl;
		printTree(r->left, h + 1); // proceed left branch below last
	}
}
void printTree_v2(Node *tree, int h)
{
	Node *r = tree;
	if (r == nullptr)
		return;
	else
	{
		if (r->right)
			printTree_v2(r->right, h + 3);
		for (int i = 0; i < h; i++)
			cout << " ";
		cout << " ";
		if (r->right)
		{
			cout << " /\n";
			for (int i = 0; i < h; i++)
				cout << " ";
			cout << " ";
		}
		cout << r->Name << "\n ";
		if (r->left)
		{
			for (int i = 0; i < h; i++)
				cout << " ";
			cout << "  \\\n";
			printTree_v2(r->left, h + 3);
		}
	}
}
void ListGraduated(Node *student)
{
	if (student == nullptr)
		return;
	else
	{
		if (student->Status == 1)
			cout << student->Name << " ";
		ListGraduated(student->left);
		ListGraduated(student->right);
	}
}
void storeInorder(Node *t, string arr[], int *i)
{
	if (t == NULL)
		return;
	storeInorder(t->left, arr, i);
	arr[*i] = t->Name;
	(*i)++;
	storeInorder(t->right, arr, i);
}
void listAllLexiOrder(Node *t)
{
	string arr[100];
	int i = 0;
	storeInorder(t, arr, &i);
	int n = sizeof(arr) / sizeof(arr[0]);
	for (int i = 0; i < n; i++)
		for (int j = i + 1; j < n; j++)
		{
			if (arr[i][0] > arr[j][0])
				swap(arr[i], arr[j]);
		}
	for (int i = 0; i < n; i++)
		if (arr[i] != "")
			cout << arr[i] << " ";
	cout << endl;
}
int countNode(Node *t)
{
	if (t == NULL)
		return 0;
	return countNode(t->left) + countNode(t->right) + 1;
}
void inorderFile(Node *t)
{
	fstream fileout("student.data.txt", ios::app);
	if (t == NULL)
		return;
	inorderFile(t->left);
	fileout << t->ID << endl;
	fileout << t->Name << endl;
	fileout << t->Birthday << endl;
	fileout << t->Status << endl;
	inorderFile(t->right);
	fileout.close();
}
void writeFile(Node *t)
{
	fstream fileout("student.data.txt", ios::app);
	int n = countNode(t);
	fileout << n << endl;
	inorderFile(t);
	fileout.close();
}
void search_graduates(Node *&student)
{
	if (student != nullptr)
	{
		if (student->Status == true)
		{
			student = delete_id(student, student->ID);
			return;
		}
		search_graduates(student->left);
		search_graduates(student->right);
	}
}
int countGraduate(Node *t)
{
	if (t == NULL)
		return 0;
	return (t->Status == 1) + countGraduate(t->left) + countGraduate(t->right);
}
void deleteGraduated(Node *&student)
{
	int temp = countGraduate(student);
	while (temp != 0)
	{
		search_graduates(student);
		temp--;
	}
}
void readfile(Node *&student, int &n)
{
	fstream file("student.data.txt", ios::in);
	if (file.fail())
		return;
	else
	{
		file >> n;
		string temp;
		getline(file, temp, '\n'); // pass the " " after the n number
		while (!file.eof())
		{
			string id, name, birthday;
			int status;
			getline(file, id, '\n');
			getline(file, name, '\n');
			getline(file, birthday, '\n');
			file >> status;
			insert(student, id, name, birthday, status);
			getline(file, temp, '\n'); //  pass the " " after the status number
		}
	}
	file.close();
}
void clearFile(string name)
{
	ofstream fileout;
	fileout.open(name, ios::out | ios::trunc);
	fileout.close();
}
void findAndUpdate(Node *t, string s)
{
	while (t != NULL)
	{
		if (stoi(t->ID) > stoi(s))
			t = t->left;
		else if (stoi(t->ID) < stoi(s))
			t = t->right;
		else
		{
			cout << "Update info: \n";
			string id, name, birthday;
			int status;
			cout << "ID: ";
			cin >> id;
			cout << "Name: ";
			cin >> name;
			cout << "Birthday: ";
			cin >> birthday;
			cout << "Status: ";
			cin >> status;
			t->ID = id;
			t->Name = name;
			t->Birthday = birthday;
			t->Status = status;
			return;
		}
	}
	cout << "\nNot Found!\n";
}
