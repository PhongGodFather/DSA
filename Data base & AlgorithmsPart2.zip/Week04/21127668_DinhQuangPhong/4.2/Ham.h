#pragma once
#ifndef Ham
#define Ham
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
struct Node
{
	string ID, Name, Birthday;
	bool Status = 0;
	Node* left, * right;
	Node(string id, string name, string birthday, bool status)
	{
		ID = id;
		Name = name;
		Birthday = birthday;
		Status = status;
		left = NULL;
		right = NULL;
	}
};
void insert(Node*& student, string id, string name, string birthday, bool status);
void out_info(Node* student);
void search_id(Node* student, string id);
Node* delete_id(Node*& student, string id);
void ListGraduated(Node* student);
void listAllLexiOrder(Node* t);
int countNode(Node* t);
void writeFile(Node* t);
void deleteGraduated(Node*& student);
void readfile(Node*& student, int& n);
void clearFile(string name);
void findAndUpdate(Node* t, string s);
#endif // !Ham
