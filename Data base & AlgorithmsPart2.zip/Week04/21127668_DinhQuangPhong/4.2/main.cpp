#include "Ham.h"
int main()
{
	Node *student = NULL;
	string id, name, birthday;
	int status;
	int n, k;
	readfile(student, n);
	cout << "1. Create new student info.======================" << endl;
	cout << "2. Find student by ID and updating.==============" << endl;
	cout << "3. List all students in lexi order.==============" << endl;
	cout << "4. List all graduated students.==================" << endl;
	cout << "5. Delete a student given by its code.===========" << endl;
	cout << "6. Delete graduates or save in file student.data." << endl;
	cout << "7. exit.=========================================" << endl
		 << endl
		 << endl;
	do
	{
		cout << "- Nhap lua chon cua ban: ";
		cin >> k;
		switch (k)
		{
		case 1:
			cout << "\n+ Nhap thong tin sinh vien: \n";
			cout << "ID: ";
			cin >> id;
			cout << "Name: ";
			cin >> name;
			cout << "Birthday: ";
			cin >> birthday;
			cout << "Status: ";
			cin >> status;
			insert(student, id, name, birthday, status);
			n = countNode(student);
			cout << "\n";
			break;
		case 2:
			cout << "\n+ Nhap ID can tim va cap nhat thong tin: \n";
			cin >> id;
			findAndUpdate(student, id);
			n = countNode(student);
			cout << "\n";
			break;
		case 3:
			cout << "\n+ List all students in lexicographic order of their names: \n";
			n = countNode(student);
			listAllLexiOrder(student);
			break;
		case 4:
			cout << "\n+ List all graduated students: \n";
			ListGraduated(student);
			n = countNode(student);
			break;
		case 5:
			cout << "\n+ Nhap ID de xoa thong tin sinh vien: \n";
			cin >> id;
			student = delete_id(student, id);
			n = countNode(student);
			break;
		case 6:
			int c;
			cout << "\n+ Nhap 1 de xoa sinh vien da Tot nghiep, 2 de luu thong tin vao file student.data: \n";
			cin >> c;
			if (c == 1)
			{
				deleteGraduated(student);
				break;
			}
			else
			{
				fstream file("student.data.txt", ios::in | ios::out);
				if (!file.fail())
				{
					readfile(student, n);
					clearFile("student.data.txt");
					writeFile(student);
					break;
				}
				else
				{
					writeFile(student);
					break;
				}
				file.close();
			}
		default:
			exit(0);
		}
	} while (true);
}