#include <iostream>
#include <map>
#include <string>
#include <fstream>
using namespace std;
struct word
{
    string data, def;
};
bool compare(string a, string b)
{
    int n = a.length() ? b.length() : a.length() < b.length();
    for (int i = 0; i < n; i++)
    {
        if (a[i] == b[i])
            continue;
        else if (a[i] < b[i])
            return true;
        else
            return false;
    }
    return false;
}
int binary_search(string key, map<int, word> a, int n)
{
    int l = 0, r = n - 1;
    while (l <= r)
    {
        int mid = l + (r - l) / 2;
        string temp = a[mid].data;
        if (temp[0] >= 'A' && temp[0] <= 'Z')
            temp[0] += 32;
        if (a[mid].data == key)
            return mid;
        if (compare(temp, key))
            l = mid + 1;
        else
            r = mid - 1;
    }
    return -1;
}
void read_dictionary_file(map<int, word> &a, int &n)
{
    n = 0;
    fstream file("English-Vietnamese Dictionary.txt", ios::in);
    while (!file.eof())
    {
        string temp1, temp2;
        getline(file, temp1, ':');
        getline(file, temp2, '\n');
        word k = {temp1, temp2};
        a.emplace(n, k);
        n++;
    }
    file.close();
}
void out_dictionary(map<int, word> a, int n)
{
    int count = 0, discount = 0;
    for (int i = 0; i < n; i++)
    {
        int temp = binary_search(a[i].data, a, n);
        if (temp != -1)
        {
            cout << a[i].data << ": " << a[i].def << endl;
            count++;
        }
        else
            discount++;
    }
    cout << count << " : " << discount << endl;
}
void file_out(char *file_name, char *keys[], int n, map<int, word> a, int m)
{
    for (int i = 1; i < n - 1; i++)
        for (int j = i + 1; j < n - 1; j++)
            if (compare(keys[j], keys[i]))
                swap(keys[i], keys[j]);
    fstream file(file_name, ios::out);
    for (int i = 1; i < n - 1; i++)
    {
        int pos = binary_search(keys[i], a, m);
        if (pos != -1)
            file << keys[i] << ": " << a[pos].def << endl;
        else
            file << keys[i] << " is not in the dictionary\n";
    }
    file.close();
}
int main(int argc, char *argv[])
{
    int n;
    map<int, word> dictionary;
    read_dictionary_file(dictionary, n);
    out_dictionary(dictionary, n);
    cout << "Finished translating !";
    file_out(argv[argc - 1], argv, argc, dictionary, n);
}