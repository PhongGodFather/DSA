#include <iostream>
#include <fstream>
using namespace std;
void read_file(int a[], int &n, char *file_in)
{
	int i = 0;
	fstream file(file_in, ios::in);
	file >> n;
	while (!file.eof())
	{
		file >> a[i];
		i++;
	}
	file.close();
}
int linear_search(int a[], int n, int x)
{
	for (int i = 0; i < n; i++)
		if (a[i] == x)
			return i;
	return -1;
}
int sentinel_search(int a[], int n, int x)
{
	int end = a[n - 1];
	a[n - 1] = x;
	int i = 0;
	while (a[i] != x)
		i++;
	a[n - 1] = end;
	if ((i < n - 1) || (a[n - 1] == x))
		return i;
	else
		return -1;
}
void sort(int a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		for (int j = i + 1; j < n; j++)
		{
			if (a[i] > a[j])
				swap(a[i], a[j]);
		}
	}
}
int binary_search(int x, int a[], int l, int r)
{
	if (l == r)
		return -1;
	int mid = l + (r - l) / 2;
	if (a[mid] == x)
		return mid;
	else if (a[mid] < x)
		return binary_search(x, a, mid, r);
	else
		return binary_search(x, a, l, mid);
}
void out_file(int a[], int n, char *file_out, int mode, int x)
{
	fstream file(file_out, ios::out);
	if (mode == 1)
	{
		for (int i = 0; i < n; i++)
		{
			if (linear_search(a, n, a[i]) != -1 && a[linear_search(a, n, a[i])] == x)
				file << i << " ";
		}
	}
	else if (mode == 2)
	{
		for (int i = 0; i < n; i++)
		{
			if (sentinel_search(a, n, x) != -1)
				file << sentinel_search(a, n, x) << " ";
		}
	}
	else
	{
		for (int i = 0; i < n; i++)
		{
			if (binary_search(x, a, 0, n - 1) != -1)
				file << binary_search(x, a, 0, n - 1) << " ";
		}
	}
	file.close();
}
int string_to_int(string a)
{
	int sum = 0;
	for (int i = 0; i < a.length(); i++)
		sum = sum * 10 + a[i] - '0';
	return sum;
}
int main(int argc, char **argv) // get the input via cmd
{
	int mode = argv[1][0] - '0';
	int x = string_to_int(argv[2]);
	int a[100], n;
	read_file(a, n, argv[3]);
	// sort(a, n);
	// cout << sentinel_search(a, n, 1);
	out_file(a, n, argv[4], mode, x);
}