#include <iostream>
using namespace std;
template <class T>
class Queue
{
private:
	int front, rear;
	T a[100];
public:
	Queue() { front = 0; rear = 0; }
	bool isEmpty() { return (front == rear); }
	bool isFull() { return (rear == 100); }
	T Front() { return a[front]; }
	void Enqueue(T item)
	{
		if (isFull())
			return;
		a[rear] = item;
		rear++;
	}
	void Dequeue() 
	{
		if (isEmpty())
			return;
		front++;
	}
};
int main()
{
	Queue<int> a;
	bool run = true;
	int t;
	do
	{
		cout << "Nhan 1 de Enqueue \n";
		cout << "Nhan 2 de Dequeue \n";
		cout << "Nhan 3 de Print \n";
		cout << "Nhan 4 de Exit \n";
		cout << "Your choice: ";
		cin >> t;
		if (t == 1)
		{
			int temp;
			cout << "Nhap vao 1 con so: ";
			cin >> temp;
			a.Enqueue(temp);
		}
		else if (t == 2)
		{
			if (a.isEmpty())
				cout << "The queue is Empty \n";
			a.Dequeue();
		}
		else if (t == 3)
		{
			Queue<int> p = a;
			if (a.isEmpty())
				cout << "The queue is Empty \n";
			else
				cout << "Content: ";
			while (!p.isEmpty())
			{
				cout << p.Front() << " ";
				p.Dequeue();
			}
			cout << endl;
		}
		else if (t == 4)
		{
			cout << "End !";
			run = false;
		}
		else
			cout << "Vui long nhap lai !\n";
	} while (run);
}