#include <iostream>
#include <fstream>
using namespace std;
int main()
{
	int row;
	fstream file("input1.3.txt", ios::in);
	file >> row;
	float a[100][100];
	for (int i = 0; i < row; i++)
		for (int j = 0; j < 12; j++)
			file >> a[i][j];
	file.close();
	float average[100];
	for (int i = 0; i < row; i++)
	{
		float ar = 0;
		for (int j = 0; j < 12; j++)
		{
			ar += a[i][j];
		}
		average[i] = ar / 12;
	}
	float max_temp[100], min_temp[100];
	for (int i = 0; i < row; i++)
	{
		float max = 0;
		float min = a[i][0];
		for (int j = 0; j < 12; j++)
		{
			if (max < a[i][j])
				max = a[i][j];
			if (min > a[i][j])
				min = a[i][j];
		}
		max_temp[i] = max;
		min_temp[i] = min;
	}
	fstream fout("output1.3.txt", ios::out);
	for (int i = 0; i < row; i++)
	{
		fout << "Max temperature of day " << i + 1 << " = " << max_temp[i] << " || ";
		fout << "Min temperature of day " << i + 1 << " = " << min_temp[i] << " || ";
		fout << "Average temperature of day " << i + 1 << " = " << average[i] << endl;
	}
	fout.close();
}