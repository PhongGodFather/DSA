#include <iostream>
#include <fstream>
#include <string>
using namespace std;
string Format_string(string a)
{
	string temp;
	for (int i = 0; i < a.length(); i++)
	{
		if (a[i] >= 'A' && a[i] <= 'Z')
			a[i] += 32;
	}
	for (int i = 0; i < a.length(); i++)
	{
		if (a[i] >= 'a' && a[i] <= 'z')
			temp.push_back(a[i]);
	}
	return temp;
}
bool Palindrom(string a)
{
	string temp = Format_string(a);
	for (int i = 0; i < temp.length(); i++)
	{
		if (temp[i] != temp[temp.length() - i - 1])
			return false;
	}
	return true;
}
int main()
{
	fstream file("input1.8.1.txt", ios::in);
	string a[100];
	int count = 0;
	while (!file.eof())
	{
		getline(file, a[count], '\n');
		count++;
	}
	for (int i = 0; i < count; i++)
	{
		if (Palindrom(a[i]))
			cout << a[i] << " is Palindrom \n";
		else
			cout << a[i] << " is not Palindrom \n";
	}
}