#include <iostream>
using namespace std;
template <class T>
class Stack
{
public:
	int Top;
	T a[100];
	T top() { return a[Top]; }
	Stack() { Top = -1; }
	bool isEmpty() { return (Top == -1); }
	bool isFull() { return (Top == 100); }
	void push(T item)
	{
		if (isFull())
			return;
		Top++;
		a[Top] = item;
	}
	void pop() 
	{ 
		if (isEmpty())
			return;
		Top--;
	}
};
int main()
{
	Stack<char> a;
	bool run = true;
	int t;
	do
	{
		cout << "Nhan 1 de push \n";
		cout << "Nhan 2 de pop \n";
		cout << "Nhan 3 de Print \n";
		cout << "Nhan 4 de Exit \n";
		cout << "Your choice: ";
		cin >> t;
		if (t == 1)
		{
			char temp;
			cout << "Nhap vao ki tu: ";
			cin >> temp;
			a.push(temp);
		}
		else if (t == 2)
		{
			if (a.isEmpty())
				cout << "The stack is Empty \n";
			a.pop();
		}
		else if (t == 3)
		{
			Stack<char> p = a;
			if (a.isEmpty())
				cout << "The stack is Empty \n";
			else
				cout << "Content: ";
			while (!p.isEmpty())
			{
				cout << p.top();
				p.pop();
			}
			cout << endl;
		}
		else if (t == 4)
		{
			cout << "End !";
			run = false;
		}
		else
			cout << "Vui long nhap lai !\n";
	} while (run);
}