#include <iostream>
#include <fstream>
#include <string>
using namespace std;
int main()
{
	int a, n;
	string c;
	cout << "Nhap vao so 1 hoac 0: ";
	cin >> a;
	while (a != 1 && a != 0)
	{
		cout << "Vui long nhap lai ! ";
		cin >> a;
	}
	cout << "\nNhap vao 1 so nguyen duong: ";
	cin >> n;
	while (n <= 0)
	{
		cout << "Vui long nhap lai ! ";
		cin >> n;
	}
	cout << "Nhap vao ten file text: ";
	cin >> c;
	fstream file(c + ".txt", ios::out);
	for (int i = 0; i < 10000; i++)
		file << i + 1 << endl;
	file.close();
	file.open(c + ".txt", ios::in);
	if (a == 0)
	{
		cout << "First " << n << " lines of the file\n";
		for (int i = 0; i < n; i++)
		{
			string temp;
			getline(file, temp, '\n');
			cout << temp << endl;
		}
		file.close();
	}
	else
	{
		cout << "Last " << n << " lines of the file\n";
		file.seekg(0, ios::end);
		int pos = file.tellg();
		int count = 0;
		for (int i = 1; i < 10000; i++)
		{
			file.seekg(-i, ios::end);
			char ch;
			file.get(ch);
			if (ch == '\n')
			{
				count++;
				if (count == 2*n + 1)
					break;
			}
		}
		while (!file.eof())
		{
			string temp;
			getline(file, temp, '\n');
			cout << temp << endl;
		}
		file.close();
	}
}