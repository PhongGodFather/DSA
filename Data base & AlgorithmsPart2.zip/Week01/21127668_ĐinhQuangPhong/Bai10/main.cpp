#include <iostream>
#include <fstream>
using namespace std;
struct Student
{
	char name[100];
	int ID;
	char birthday[100];
	char address[100];
	char Class[10];
};
int main()
{
	Student a;
	fstream file("output1.9.bin", ios::binary | ios::in);
	file.read((char*)&a, sizeof(a));
	file.close();
	cout << "Name: " << a.name << endl;
	cout << "ID: " << a.ID << endl;
	cout << "Class: " << a.Class << endl;
	cout << "Birthday: " << a.birthday << endl;
	cout << "Address: " << a.address;
}