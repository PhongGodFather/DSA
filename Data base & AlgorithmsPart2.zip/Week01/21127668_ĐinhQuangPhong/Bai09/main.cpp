#include <iostream>
#include <fstream>
#include <string>
using namespace std;
struct Student
{
	char name[100];
	int ID;
	char birthday[100];
	char address[100];
	char Class[10];
};
int main()
{
	cout << "Write anything to begin entering...";
	string temp;
	cin >> temp;
	cin.ignore();
	Student a;
	cout << "Name: ";
	cin.getline(a.name, 100);
	cout << "ID: ";
	cin >> a.ID;
	cin.ignore();
	cout << "Class: ";
	cin.getline(a.Class, 10);
	cout << "Birthday: ";
	cin.getline(a.birthday, 100);
	cout << "Address: ";
	cin.getline(a.address, 100);
	fstream file("output1.9.bin", ios::binary | ios::out);
	file.write((char*)&a, sizeof(a));
	file.close();
}