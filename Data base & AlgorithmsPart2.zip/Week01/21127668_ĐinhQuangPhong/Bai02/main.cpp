#include <iostream>
#include <fstream>
using namespace std;
struct PhanSo
{
	int tu, mau;
};
int gcd(int a, int b)
{
	int ucln = a ? b : a >= b;
	while (ucln != 1)
	{
		if (a % ucln == 0 && b % ucln == 0)
			return ucln;
		ucln--;
	}
}
int main()
{
	fstream file("input1.2.txt", ios::in);
	int row, col;
	PhanSo a[100][100];
	file >> row >> col;
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			char c;
			file >> a[i][j].tu >> c >> a[i][j].mau;
		}
	}
	file.close();
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			int temp = gcd(a[i][j].tu, a[i][j].mau);
			a[i][j].tu /= temp;
			a[i][j].mau /= temp;
		}
	}
	fstream fout("output1.2.txt", ios::out);
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
			fout << a[i][j].tu << "/" << a[i][j].mau << " ";
		fout << endl;
	}
	fout.close();
}