#include <iostream>
#include <string>
#include <fstream>
#include <set>
using namespace std;
int main()
{
	string a[100];
	set<string> DS;
	int i = 0;
	fstream file("input1.1.txt", ios::in);
	cout << "Content: ";
	while (file >> a[i])
	{
		DS.emplace(a[i]);
		cout << a[i] << " ";
		i++;
	}
	file.close();
	cout << endl;
	cout << "There are " << DS.size() << " distinct words: ";
	int count = 0;
	for (set<string>::iterator k = DS.begin(); k != DS.end(); k++)
		cout << *k << " ";
	fstream File("input1.1.txt", ios::in);
	string sentence[100];
	int k = 0;
	while (!File.eof())
	{
		getline(File, sentence[k], '.');
		k++;
	}
	File.close();
	cout << "\n There are " << k - 1 << " sentences: ";
	for (int p = 0; p < k - 1; p++)
		cout << sentence[p] << endl;
}