#include <iostream>
#include <fstream>
#include <string>
using namespace std;
int main()
{
	int i1 = 0, i2 = 0;
	string word1[100];
	string word2[100];
	fstream file1("input1.4.1.txt", ios::in);
	fstream file2("input1.4.2.txt", ios::in);
	while (!file1.eof())
	{
		getline(file1, word1[i1], '\n');
		i1++;
	}
	while (!file2.eof())
	{
		getline(file2, word2[i2], '\n');
		i2++;
	}
	for (int i = 0; i < i1; i++)
	{
		if (word1[i] == word2[i])
			cout << i + 1 << "//" << word1[i] << endl;
		else
			cout << i + 1 << "\\" << word2[i] << endl;
	}
}