#include "Ham.h" 
#include <fstream>
#include <string>
void read_file(Employee a[], int &n)
{
	fstream file("employee.txt", ios::in);
	int i = 0;
	while (!file.eof())
	{
		string nice;
		int temp;
		getline(file, a[i].id, ',');
		getline(file, a[i].name, ',');
		file >> temp;
		getline(file, nice, '\n');
		a[i].age = 2022 - temp;
		i++;
	}
	n = i;
};
void sort_list(Employee a[], int n, int mode)
{
	if (mode == 1)
		heap_sort(a, n);
	else if (mode == 2)
		quick_sort(a,0,n - 1);
	else
	{
		Employee aux[100];
		for (int i = 0; i < n; i++)
			aux[i] = a[i];
		merge_sort(a, aux, 0, n - 1);
	}
	sort_name(a, n);
}
void write_file(Employee a[], int n)
{
	fstream file("sortedemponage.txt", ios::out);
	for (int i = 0; i < n; i++)
		file << a[i].id << "," << a[i].name << " ,age: " << a[i].age << endl;
}
int main()
{
	int n, temp;
	cout << "Choose mode number 1,2,3 : ";
	cin >> temp;
	Employee a[100];
	read_file(a, n);
	sort_list(a, n, temp); // choose mode 1,2,3,... for each sorting methods
	write_file(a, n);
	cout << "File written completed";
}