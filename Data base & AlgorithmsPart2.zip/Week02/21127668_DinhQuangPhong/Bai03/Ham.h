#pragma once
#ifndef Ham
#define Ham
#include <iostream>
using namespace std;
struct Employee
{
	string name, id;
	int age;
};
void heap_sort(Employee arr[], int n);
void quick_sort(Employee a[], int l, int r);
void merge_sort(Employee a[], Employee aux[], int l, int r);
void sort_name(Employee a[], int n);
#endif // !Ham
