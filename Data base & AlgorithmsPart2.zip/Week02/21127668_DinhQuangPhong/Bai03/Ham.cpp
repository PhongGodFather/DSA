#include "Ham.h"
void sort_name(Employee a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		for (int j = i + 1; j < n; j++)
		{
			if (a[j].age == a[i].age && a[j].name[0] < a[i].name[0])
				swap(a[i], a[j]);
		}
	}
}
void heapify(Employee arr[], int n, int i)
{
	int largest = i;
	int l = 2 * i + 1;
	int r = 2 * i + 2;
	if (l < n && arr[l].age < arr[largest].age)
		largest = l;
	if (r < n && arr[r].age < arr[largest].age)
		largest = r;
	if (largest != i) 
	{
		swap(arr[i], arr[largest]);
		heapify(arr, n, largest);
	}
}
void heap_sort(Employee arr[], int n)
{
	for (int i = n / 2 - 1; i >= 0; i--)
		heapify(arr, n, i);
	for (int i = n - 1; i > 0; i--) 
	{
		swap(arr[0], arr[i]);
		heapify(arr, i, 0);
	}
}
int partition(Employee a[], int l, int r)
{
	swap(a[l], a[r]);
	int i = l - 1, j = r;
	int v = a[r].age;
	for (;;)
	{
		while (a[++i].age > v);
		while (v > a[--j].age)
			if (j == l)
				break;
		if (i >= j)
			break;
		swap(a[i], a[j]);
	}
	swap(a[i], a[r]);
	return i;
}
void quick_sort(Employee a[], int l, int r)
{
	if (r <= l)
		return;
	int i = partition(a, l, r);
	quick_sort(a, l, i - 1);
	quick_sort(a, i + 1, r);
}
void merge(Employee arr[], Employee aux[], int low, int mid, int high)
{
	int k = low, i = low, j = mid + 1;
	while (i <= mid && j <= high)
	{
		if (arr[i].age > arr[j].age)
			aux[k++] = arr[i++];
		else
			aux[k++] = arr[j++];
	}
	while (i <= mid)
		aux[k++] = arr[i++];
	for (int i = low; i <= high; i++)
		arr[i] = aux[i];
}
void merge_sort(Employee a[], Employee aux[], int l, int r)
{
	if (r <= l)
		return;
	int m = (l + r) / 2;
	merge_sort(a, aux, l, m);
	merge_sort(a, aux, m + 1, r);
	merge(a, aux, l, m, r);
}