#include <iostream>
using namespace std;
void sort_array(int a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		if (a[i] % 2 != 0)
		{
			for (int j = i + 1; j < n; j++)
			{
				if (a[j] % 2 != 0 && a[j] > a[i]) // odd in descending
					swap(a[i], a[j]);
			}
		}
		else
		{
			for (int j = i + 1; j < n; j++)
			{
				if (a[j] % 2 == 0 && a[j] < a[i]) // even in ascending
					swap(a[i], a[j]);
			}
		}
	}
}
int main()
{
	int a[] = {1, 2, 4, 7, 15, 18, 8, 9, 11};
	sort_array(a, sizeof(a) / sizeof(a[0]));
	for (int i = 0; i < sizeof(a) / sizeof(a[0]); i++)
		cout << a[i] << " ";
}