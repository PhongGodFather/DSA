#pragma once
#ifndef Ham
#define Ham
void random_array(int a[], int n);
void create_auxilary(int a[], int aux[], int n);
void print_array(int a[], int n);
void insertion_sort(int a[], int n);
void heap_sort(int a[], int n);
void quick_sort(int a[], int l, int r);
void merge_sort(int a[], int aux[], int l, int r);
#endif // !Ham
