#include "Ham.h"
#include <iostream>
#include <time.h>
using namespace std;
void random_array(int a[], int n)
{
    srand((unsigned int)time(NULL));
    for (int i = 0; i < n; i++)
        a[i] = rand();
}
void create_auxilary(int a[], int aux[], int n)
{
    for (int i = 0; i < n; i++)
        aux[i] = a[i];
}
void print_array(int a[], int n)
{
    for (int i = 0; i < n; i++)
        cout << a[i] << " ";
}
void insertion_sort(int arr[], int n)
{
    int i, key, j;
    for (i = 1; i < n; i++)
    {
        key = arr[i];
        j = i - 1;
        while (j >= 0 && arr[j] > key)
        {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = key;
    }
}
void heapify(int arr[], int n, int i)
{
    int largest = i;
    int l = 2 * i + 1;
    int r = 2 * i + 2;
    if (l < n && arr[l] > arr[largest])
        largest = l;
    if (r < n && arr[r] > arr[largest])
        largest = r;
    if (largest != i) {
        swap(arr[i], arr[largest]);
        heapify(arr, n, largest);
    }
}

void heap_sort(int arr[], int n)
{
    for (int i = n / 2 - 1; i >= 0; i--)
        heapify(arr, n, i);
    for (int i = n - 1; i > 0; i--) {
        swap(arr[0], arr[i]);
        heapify(arr, i, 0);
    }
}
int partition(int a[], int l, int r)
{
    swap(a[l], a[r]);
    int i = l - 1, j = r;
    int v = a[r];
    for (;;)
    {
        while (a[++i] < v);
        while (v < a[--j])
            if (j == l)
                break;
        if (i >= j)
            break;
        swap(a[i], a[j]);
    }
    swap(a[i], a[r]);
    return i;
}
void quick_sort(int a[], int l, int r)
{
    if (r <= l)
        return;
    int i = partition(a, l, r);
    quick_sort(a, l, i - 1);
    quick_sort(a, i + 1, r);
}
void merge(int arr[], int aux[], int low, int mid, int high)
{
    int k = low, i = low, j = mid + 1;
    while (i <= mid && j <= high)
    {
        if (arr[i] <= arr[j])
            aux[k++] = arr[i++];
        else
            aux[k++] = arr[j++];
    }
    while (i <= mid)
        aux[k++] = arr[i++];
    for (int i = low; i <= high; i++)
        arr[i] = aux[i];
}
void merge_sort(int a[], int aux[], int l, int r)
{
    if (r <= l)
        return;
    int m = (l + r) / 2;
    merge_sort(a, aux, l, m);
    merge_sort(a, aux, m + 1, r);
    merge(a, aux, l, m, r);
}