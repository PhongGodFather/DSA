#include <iostream>
#include "Ham.h"
using namespace std;
int main()
{
	int a[10000];
	int aux[10000];
	random_array(a, 1000);
	int n = sizeof(a) / sizeof(a[0]);
	create_auxilary(a, aux, n);
	// remove the // when u need to compare between those functions
	//insertion_sort(a,n);
	//heap_sort(a,n);
	//quick_sort(a, 0, n - 1);
	merge_sort(a, aux, 0, n - 1);
	print_array(a, n);
}