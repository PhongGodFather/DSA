#include <iostream>
using namespace std;
template <class Item>
void insertion_1(Item a[], int n) // remake by myself
{
    for (int i = 1; i < n; i++)
    {
        Item v = a[i];
        for (int j = i - 1; j >= 0 && v < a[j]; j--)
        {
            a[j + 1] = a[j];
            a[j] = v;
        }
    }
}
void insertionSort(int arr[], int n) // on geeksforgeeks
{
    for (int i = 1; i < n; i++)
    {
        int key = arr[i];
        int j = i - 1;
        // Move elements of arr[0..i-1],
        // that are greater than key, to one
        // position ahead of their
        // current position
        while (j >= 0 && arr[j] > key)
        {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}
int main()
{
    int a[] = {4, 5, 1, 2, 3, 8, 7, 9};
    insertion_1(a, sizeof(a) / sizeof(a[0]));
    for (int i = 0; i < sizeof(a) / sizeof(a[0]); i++)
        cout << a[i] << " ";
}