#include <iostream>
using namespace std;
int max_sum_subarray(int a[], int n) // with O(n) speed
{
    int best = 0, sum = 0;
    for (int i = 0; i < n; i++)
    {
        sum = max(a[i], sum + a[i]);
        best = max(sum, best);
    }
    return best;
}
int main()
{
    int a[] = {1, 6, -10, 8, 2};
    cout << max_sum_subarray(a, sizeof(a) / sizeof(a[0]));
}