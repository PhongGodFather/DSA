#include <iostream>
#include <string>
#include <stack>
using namespace std;
struct Info
{
    int l, r;
};
template <class Item>
int partition(Item a[], int l, int r)
{
    // select the first as pivot still corrects // the updated one that still make the code run as good as usual
    swap(a[l], a[r]);
    // the normal code
    int i = l - 1, j = r;
    Item v = a[r];
    for (;;)
    {
        while (a[++i] < v)
            ;
        while (v < a[--j])
            if (j == l)
                break;
        if (i >= j)
            break;
        swap(a[i], a[j]);
    }
    swap(a[i], a[r]);
    return i;
}
template <class Item>
void quicksort(Item a[], int l, int r)
{
    if (r <= l)
        return;
    int i = partition(a, l, r);
    quicksort(a, l, i - 1);
    quicksort(a, i + 1, r);
}
template <class Item>
void quicksort_without_recursion(Item a[], int l, int r)
{
    stack<Item> k;
    Item stack[r - l + 1];
    int top = -1;
    stack[top++] = l;
    stack[top++] = r;
    while (top >= 0)
    {
        r = stack[top--];
        l = stack[top--];
        int p = partition(a, l, r);
        if (p - 1 > l)
        {
            stack[top++] = l;
            stack[top++] = p - 1;
        }
        if (p + 1 < r)
        {
            stack[top++] = p + 1;
            stack[top++] = r;
        }
    }
}
int main()
{
    int a[] = {5, 5, 6, 2, 1, 3, 9, -10};
    quicksort_without_recursion(a, 0, sizeof(a) / sizeof(a[0]));
    for (int i = 0; i < sizeof(a) / sizeof(a[0]); i++)
        cout << a[i] << " ";
}