#include <iostream>
using namespace std;
void heapify(int a[], int n, int i)
{
    int v = a[i];
    while (i < n / 2)
    {
        int child = 2 * i + 1;
        if (child < n - 1)
            if (a[child] > a[child + 1])
                child++;
        if (v >= a[child])
            break;

        a[i] = a[child];
        i = child;
    }
    a[i] = v;
}
void heapsort(int a[], int l, int r)
{
    int *pa = a + l;
    int N = r - l + 1;
    for (int k = N / 2 - 1; k >= 0; k--)
        heapify(pa, N, k);
    while (N > 1)
    {
        swap(pa[0], pa[N - 1]);
        N--;
        heapify(pa, N, 0);
    }
}
int main()
{
    int a[] = {43, 1, 457, 8, 7};
    heapsort(a, 0, 4);
    for (int i = 0; i < 5; i++)
        cout << a[i] << " ";
}