#include <iostream>
#include <set>
#include <map>
using namespace std;
// DFS or depth first search, the method of searching in graph
template <class Vertex>
struct Graph
{
    set<Vertex> vList;
    map<Vertex, set<Vertex>> adjList;
    void addVertex(Vertex v) { vList.insert(v); }
    void printInfo()
    {
        for (auto e : vList)
            cout << e << " ";
        cout << endl;
    }
    void addEdge(Vertex first, Vertex second)
    {
        addVertex(first);
        addVertex(second);
        adjList[first].insert(second);
        adjList[second].insert(first);
    }
    int getDegree(Vertex v) { return adjList[v].size(); }
    void printDegrees()
    {
        for (auto v : vList)
            cout << v << " ";
        cout << endl;
    }
    void printRelationship()
    {
        for (auto i : vList)
        {
            cout << i << " :";
            for (auto j : adjList[i])
                cout << "\n<--->" << j;
            cout << endl
                 << endl;
        }
    }
    int count = 0;
    void DFS(Vertex x, map<Vertex, bool> &visited)
    {
        count++;
        cout << x << "-->";
        visited[x] = true;
        for (auto j : adjList[x])
            if (!visited[j])
                DFS(j, visited);
        cout << endl;
    }
    // void DFS_noRecursion(Vertex x)
    // {
    //     map<Vertex, bool> &visited;
    //     cout << x << "-->";
    //     visited[x] = true;
    //     for (auto j : adjList[x])
    //         if (!visited[j])
    //             DFS(j, visited);
    //     cout << endl;
    // }
    void printRoadFrom(Vertex x)
    {
        map<Vertex, bool> visited;
        DFS(x, visited);
        cout << endl;
        count = 0;
    }
    void countRoadFrom(Vertex x)
    {
        map<Vertex, bool> visited;
        DFS(x, visited);
        cout << "Roads from " << x << " : " << count - 1 << endl;
        count = 0;
    }
    bool DFS_find_path(Vertex start, Vertex end, map<Vertex, bool> &check, set<Vertex> &path)
    {
        check[start] = true;
        if (start == end)
            return true;
        for (auto i : adjList[start])
            if (!check[i])
            {
                path.insert(i);
                if (DFS_find_path(i, end, check, path))
                    return true;
            }
        return false;
    }
    void Find_Path(Vertex start, Vertex des)
    {
        map<Vertex, bool> check;
        set<Vertex> paths;
        if (DFS_find_path(start, des, check, paths))
        {
            cout << start;
            for (auto i : paths)
                cout << "-->" << i;
            cout << endl;
        }
        else
            cout << " NO WAY TO THERE \n";
    }
};
int main()
{
    Graph<string> a;
    a.addEdge("A", "B");
    a.addEdge("B", "C");
    a.addEdge("C", "D");
    a.addEdge("D", "E");
    a.addEdge("A", "K");
    a.addEdge("K", "C");
    a.addEdge("C", "H");
    a.addEdge("H", "E");
    a.addEdge("A", "J");
    a.addEdge("J", "E");
    a.printRoadFrom("A");
    a.Find_Path("A", "K");
}