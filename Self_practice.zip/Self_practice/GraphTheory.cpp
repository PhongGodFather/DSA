#include <iostream>
#include <set>
#include <map>
using namespace std;
template <class Vertex>
struct Graph
{
    set<Vertex> vList;
    map<Vertex, set<Vertex>> adjList;
    void addVertex(Vertex v) { vList.insert(v); }
    void printInfo()
    {
        for (auto e : vList)
            cout << e << " ";
        cout << endl;
    }
    void addEdge(Vertex first, Vertex second)
    {
        addVertex(first);
        addVertex(second);
        adjList[first].insert(second);
        adjList[second].insert(first);
    }
    int getDegree(Vertex v) { return adjList[v].size(); }
    void printDegrees()
    {
        for (auto v : vList)
            cout << v << " ";
        cout << endl;
    }
    void printRelationship()
    {
        for (auto i : vList)
        {
            cout << i << " :";
            for (auto j : adjList[i])
                cout << "\n<--->" << j;
            cout << endl
                 << endl;
        }
    }
    bool isComplete() // a complete graph is a graph that has no vertex lonely with only one edge
    {
        for (auto v : vList)
        {
            if (getDegree(v) != adjList.size() - 1)
                return false;
        }
        return true;
    }
};
int main()
{
    Graph<string> G;
    // G.addVertex("Lan");
    // G.addVertex("Dung");
    // G.addVertex("Van");
    // G.addVertex("Phong");
    G.addEdge("Phong", "Lan");
    G.addEdge("Phong", "Van");
    G.addEdge("Van", "Lan");
    G.addEdge("Van", "Hieu");
    G.printInfo();
    cout << "The number of friends of Van: " << G.getDegree("Van") << endl;
    cout << "The number of friends of Hieu: " << G.getDegree("Hieu") << endl;
    cout << "The number of friends of Lan: " << G.getDegree("Lan") << endl;
    cout << "The number of friends of Phong: " << G.getDegree("Phong") << endl;
    cout << G.isComplete() << endl;
    G.printRelationship();
}